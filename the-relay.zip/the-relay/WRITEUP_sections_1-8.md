# The Relay — Write-up (headings 1–8)

Status note: everything below marked with real numbers comes from measured runs
(`results/results.csv`, 115 rows across 5 stand-in load scenarios, recomputed via
`scripts/analyze.py`). Items requiring the real Groq free-tier service (Table 1 limits,
the 15-question quality grading, Table 3 retrieval sweep) are marked **not measured** —
`scripts/probe_groq.py`, `scripts/eval_quality.py`, and `scripts/run_retrieval_settings.py`
are written and ready, pending a `GROQ_API_KEY`.

## 1 What I built and why

A 6-step pipeline over three pinned arXiv papers ("Attention Is All You Need" v7,
"Moshi" v1, "Dynamic Chunking" v2): (1) extract a search query from the question,
(2) retrieve passages via BM25 — the one tool call, (3) a sufficiency loop that
broadens the query and re-retrieves up to 2 extra times if the best match is weak,
(4) a streamed draft answer that must cite `[paper_id pN]` tags, (5) a
citation-verify branch that rejects any answer whose citations don't map to
real retrieved chunks (one revise attempt, else a refusal), (6) respond with
full timing/outcome logging.

**The one decision that shaped it most: retrieval is pure lexical (BM25), not
embeddings.** Groq's free tier has no embedding endpoint, and pulling in a
second provider just for embeddings would contradict "use Groq for the model
calls." This pushed quality control downstream into the citation-verify
branch — the system can't lean on semantic retrieval being "close enough," so
every claim has to be checked against literal chunk tags before it's allowed
out. This decision is also what produced the retry finding in heading 6: a
stand-in with no real citation tags in its text trips that branch on 100% of
requests.

## 2 The real service and my stand-in

**Real service (Groq):** not measured yet — no API key has been supplied in
this session, so `scripts/probe_groq.py` (which reads live `x-ratelimit-*`
headers and the `retry-after` header on a 429, and fires 5 concurrent requests
to find the in-flight limit) has not been run. Once it is, Table 1 will be
filled from those headers directly, not guessed.

**Stand-in** (`src/standin_server.py`): a real local FastAPI/uvicorn HTTP
server, not an in-process stub, so it exhibits genuine connection and
concurrency behavior. It streams tokens one at a time with a lognormal
per-token delay and a lognormal time-to-first-token; a load-dependent
slowdown multiplier tied to the number of concurrent in-flight requests;
configurable hard-failure and slow-success probabilities; and its own
RPM/RPD counters that return HTTP 429 with a `retry-after` header once
tripped.

**Calibration:** latency parameters are placeholders pending the real Groq
probe (currently tuned by hand to produce realistic-looking distributions,
not yet matched to measured percentiles) — this is flagged honestly rather
than presented as calibrated.

**Where it differs most from the real thing:** the stand-in draws i.i.d.
latency samples per request. Groq's real latency comes from a shared,
multi-tenant queue, so real slow periods are correlated across many
different callers at once — everyone gets slow together. The stand-in's
load-slowdown multiplier only sees *this process's own* concurrency, so it
cannot reproduce that cross-tenant correlation; it will understate how bad a
real shared-service incident looks.

## 3 Results

All runs below used the **stand-in** (no real Groq runs have been made yet in
this session). Load scenarios ran against a stand-in instance launched fresh
per scenario; percentiles are p50/p95/p99 computed from `results/results.csv`.

**Table 2a — Latency**

| Scenario | Real/stand-in | Requests sent | Duration (s) | Offered rate (per min) | First token p50/p95/p99 (ms) | Total time p50/p95/p99 (ms) |
|---|---|---|---|---|---|---|
| steady | stand-in | 20 | 136.0 | 8.8 | 303 / 912 / 3232 | 4113 / 18858 / 21217 |
| burst | stand-in | 20 | 39.6 | 30.3 | 702 / 2115 / 3814 | 8005 / 38681 / 39314 |
| sustained_overload | stand-in | 30 | 7.2 | 249.5 | 295 / 674 / 695 | 31 / 6516 / 6955 |
| per_minute_halved | stand-in | 30 | 12.8 | 140.4 | 435 / 991 / 1058 | 4003 / 7719 / 8545 |
| daily_exhausted | stand-in | 15 | 3.2 | 279.0 | not measured (no model call made) | 0 / 34 / 34 |
| probe (Groq baseline) | real | not measured | not measured | not measured | not measured | not measured |

**Table 2b — Outcomes**

| Scenario | Succeeded % | Rate-limited % | Timed out/given up % | Retries per request | Peak queue length | Tokens per answer | Cost per 1,000 answers |
|---|---|---|---|---|---|---|---|
| steady | 100.0% | 0.0% | 0.0% | 1.00 | 1 | 113.5 | $0 (local stand-in) |
| burst | 100.0% | 0.0% | 0.0% | 1.00 | 20 | 87.2 | $0 (local stand-in) |
| sustained_overload | 33.3% | 66.7% | 0.0% | 0.33 | 10 | 28.2 | $0 (local stand-in) |
| per_minute_halved | 63.3% | 36.7% | 0.0% | 0.63 | 10 | 53.9 | $0 (local stand-in) |
| daily_exhausted | 0.0% | 100.0% | 0.0% | 0.00 | 1 | 0.0 | $0 (local stand-in) |

**Number we could not have guessed without running it:** retries-per-request
is exactly **1.00 on both `steady` and `burst`** — every single request, with
no exceptions, triggers the citation-verify branch's revise attempt. That's
not a tuned parameter; it fell out of the fact that the stand-in's canned
answer text never happens to contain a real `[paper_id pN]` tag, so the
verify check fails 100% of the time. We would not have predicted a clean
100% without running it — a slightly different canned-text template could
easily have given a partial rate instead.

**Answer quality on 15 handwritten questions:** not measured — needs the real
Groq model to be meaningful (the stand-in's text is generic and not
intended to answer the question content, only to exercise timing/failure
paths). The 15 questions are written and ready in `questions_quality.json`;
`scripts/eval_quality.py` will run them and prompt for a human grade
(correct / wrong / refused_correctly / refused_wrongly) once a key is
available. Tokens used per answer: not measured for the same reason.

## 4 Where the time goes

Picked one deliberately slow stand-in request (forced into the slow path via
`scripts/time_breakdown.py`, request_id `d92827a2`, which made 2 model calls
— an initial draft and one citation-verify retry):

| Call | Waiting (before 1st token) | Working (after 1st token) | Call total |
|---|---|---|---|
| draft (initial) | 1,416 ms | 6,421 ms | 7,837 ms |
| retry (citation-verify revise) | 731 ms | 4,037 ms | 4,768 ms |

Pipeline total: 12,605 ms (= 7,837 + 4,768, checked programmatically — the
script asserts the sum of per-call totals equals the pipeline's reported
`total_ms`).

**The delay came after the first token, not before.** On the initial draft
call, waiting (1,416 ms) was far smaller than working (6,421 ms) — most of
the latency is token-generation time once streaming has already started,
not queueing/startup time. "Retrying" here means the entire second call
(4,768 ms) — none of it is wasted on top of the first call, it's a fully
separate 2nd round-trip caused by the citation-verify branch rejecting the
first answer.

## 5 When a limit is hit

**Per-minute limit:** enforced two ways — the stand-in's own RPM counter
(returns HTTP 429 + `retry-after`) and `src/budget.py`'s local tracker in
front of the pipeline. On hitting it, the caller is **delayed**: the
pipeline sleeps up to the remaining time in the current minute window, then
rechecks once. If still blocked, the request is marked `rate_limited` and
returned to the caller rather than retried indefinitely. Measured evidence:
`per_minute_halved` (stand-in RPM capped at 15, 30 requests fired) —
63.3% succeeded, 36.7% were rate-limited, nobody got a silently degraded
answer; they were cleanly told the request was rate-limited.

**Per-day limit:** `BudgetExhausted` in `src/budget.py` — no amount of
waiting helps within the session, so the caller is **immediately refused**,
with **no model call made at all** (so it costs nothing). Measured evidence:
`daily_exhausted` (local `rpd_limit=5`, 15 requests fired) — 100%
rate-limited, median total_ms = 0 (confirms no model call occurred), p99 = 34
ms (just the overhead of the budget check itself).

**Who is delayed / dropped / weakened:** nobody gets a silently weaker
answer in either case — the design deliberately avoids sending an
unverified or low-confidence answer just to "look" successful (per the
brief's rule against embarrassing answers). Per-minute: delayed, then
possibly dropped (marked `rate_limited`) if the delay doesn't clear it.
Per-day: dropped immediately, with an explicit message (see heading 7)
rather than a degraded answer.

## 6 Retries

**Policy:** exactly one retry point in the whole pipeline — the
citation-verify branch allows one revise attempt if the drafted answer's
citations don't match retrieved chunks. The budget tracker allows one
wait-and-recheck at the per-minute limit. No blind retries on timeout or
error, to avoid piling more load onto an already-struggling model service.

**Case where retrying made things worse:** confirmed with real data from the
`steady` and `burst` scenarios above — retries-per-request = **1.00** in
both. Against the stand-in, the citation-verify retry fires on literally
every request and never once succeeds, because the stand-in's canned text
never contains a real citation tag. Each retry burns a full second model
call — per the heading-4 breakdown, up to ~4.8 seconds — and the outcome is
identical either way: a refusal. Net effect of the retry policy here: pure
added latency and token cost, zero quality improvement.

## 7 What the person sees

At 3pm the daily budget is gone. The pipeline detects this before making any
model call (`BudgetExhausted` branch in `src/pipeline.py`) and returns:

> "The daily question budget has been used up for today. Please try again
> after it resets, or ask a shorter, more specific question tomorrow — no
> new answers can be generated until the budget resets."

This is fast (confirmed: median total_ms = 0 in the `daily_exhausted`
scenario) because no model call happens — the person isn't left waiting on a
hung request, they get an immediate, explicit explanation instead of a
timeout or a degraded answer.

## 8 What I'm unsure about, what I left out, what I learned

**Least certain assumption:** that the stand-in's i.i.d. lognormal latency
model is "close enough" to Groq's real distribution for the load-shape
results to generalize. Since no real Groq probe has been run yet in this
session, this is currently an unverified assumption rather than a calibrated
one. If real Groq latency is more heavily correlated across concurrent
callers than i.i.d. sampling captures (likely, given it's a shared queue),
the burst/sustained-overload numbers above probably *underestimate* real
tail latency during an actual incident.

**Two things I deliberately did not build:**
1. Semantic/embedding retrieval — ruled out by the "use Groq" constraint (no
   embedding endpoint on the free tier), not by choice.
2. A persistent request queue across process restarts — the budget tracker
   and in-flight counters are in-memory only; a real deployment would need a
   shared store (e.g. Redis) across replicas.

**One thing that was new to me:** Groq's rate-limit response headers are
named for one window but constrain another — `x-ratelimit-limit-requests`
actually refers to the **requests-per-day** cap, and `x-ratelimit-limit-tokens`
refers to **tokens-per-minute**, per Groq's own docs. The header names don't
match the window they describe, which is an easy thing to misread the first
time you look at them.

<!--
DRAFT / SKELETON — fill in bracketed [TODO: ...] sections with real numbers
once scripts/probe_groq.py, scripts/run_load.py (all 5 scenarios),
scripts/run_retrieval_settings.py and scripts/eval_quality.py have been run
with a real GROQ_API_KEY. Target length: 2 pages once numbers replace TODOs.
-->

# The Relay — write-up

## 1 What I built and why

A 6-step pipeline over three pinned arXiv papers: classify intent/extract a search
query, retrieve passages (BM25 tool call), a sufficiency loop that broadens the
query and re-retrieves (up to 2 extra tries) if the best match is weak, a
streamed draft answer that must cite `[paper_id pN]` tags, a citation-verify
branch that rejects any answer whose citations don't map to real retrieved
chunks (one revise attempt, else a refusal), and a response step.

**The one decision that shaped it most: retrieval is pure lexical (BM25), not
embeddings.** Groq's free tier has no embedding endpoint, and pulling in a
second provider just for embeddings would contradict "use Groq for the model
calls." This pushed quality control downstream into the citation-verify
branch — the system can't lean on semantic retrieval being "close enough," so
every claim has to be checked against literal chunk tags before it's allowed
out the door. [TODO: reference actual pass/fail rate of citation-verify once
eval_quality.py + run_retrieval_settings.py have run.]

## 2 The real service and my stand-in

[TODO: fill after scripts/probe_groq.py run]
- Requests per minute: [TODO]
- Tokens per minute: [TODO]
- Requests/tokens per day: [TODO]
- What a 429 looks like: [TODO — status code, headers seen]
- How found: `scripts/probe_groq.py`, N=[TODO] real requests, see `results/probe_real.csv`.

**Stand-in behavior** (`src/standin_server.py`): FastAPI server with a
lognormal per-token delay and lognormal time-to-first-token, both calibrated
from the real probe's median/p95; a load-dependent slowdown multiplier tied to
concurrent in-flight requests; configurable hard-failure and
slow-success probabilities; and its own RPM/RPD counters that return 429 with
a `retry-after` header once tripped.

**Where it differs most from the real thing:** the stand-in draws i.i.d.
latency samples per request. Groq's real latency is driven by a shared,
multi-tenant queue, so real slow requests are correlated across many
different callers at once (everyone gets slow together), not independent per
request. The stand-in's `load_slowdown_per_inflight` only sees *this
process's* concurrency, so it can't reproduce that cross-tenant correlation.

## 3 Results

[TODO: paste Table 2a / 2b here after all 5 scenarios + probe have run,
recomputed via `scripts/analyze.py` from `results/results.csv`]

Answer quality on 15 handwritten questions (`questions_quality.json`,
graded in `results/quality_grades.json`): [TODO — counts of
correct/wrong/refused_correctly/refused_wrongly out of 15, plus mean
tokens per answer].

Number we couldn't have guessed without running it: [TODO — e.g. the
measured retry-after value on Groq's actual 429, or the stand-in's observed
retries-per-request under burst].

## 4 Where the time goes

[TODO: pick one slow request from results.csv (highest total_ms in a
load-test run), and break down: time before first token (waiting on
queue/startup) vs. time generating tokens after first token (working) vs.
time spent on the citation-verify retry (retrying). Show the math: e.g.
total_ms - first_token_ms = generation+retry time; the citation-verify branch
issues a second chat_stream call whose total_ms is in `stream_results`
(logged internally, not currently a CSV column — note this as a limitation
or add a breakdown column before the final run).]

Delay came [before/after] the first token: [TODO].

## 5 When a limit is hit

**Per-minute limit** (`src/budget.py` / stand-in's own RPM counter): the
caller is delayed — the pipeline sleeps up to the time left in the current
minute window, then retries the budget check once; if still blocked, the
request is marked `rate_limited` and returned to the caller rather than
silently retried forever.

**Per-day limit** (`BudgetExhausted` in `src/budget.py`): no amount of
waiting helps within the session, so the caller is immediately refused with
the fixed message in heading 7 — no model call is made at all, so it costs
nothing.

Who is delayed / dropped / weakened: [TODO — fill in from
`daily_exhausted` and `per_minute_halved` scenario rows in results.csv].

## Retrieval: quality versus cost

Three settings tried (`scripts/run_retrieval_settings.py`):
1. `small_k3_norerank` — 100-word chunks, k=3, no re-rank
2. `medium_k5_norerank` — 200-word chunks, k=5, no re-rank
3. `medium_k5_rerank` — 200-word chunks, k=5, lexical overlap re-rank

[TODO: paste Table 3 here after run]

Chosen setting: **medium_k5_norerank** (current default in
`scripts/eval_quality.py`) — [TODO: justify once numbers are in; likely
"the extra re-rank pass added tokens/latency without changing grades," or
revise justification based on actual results].

What I do with retrieval when the limit is close: reduce k (fewer chunks →
fewer input tokens) and keep max_tokens on the draft call fixed, since input
tokens are what consume quota headroom the fastest on a token-per-minute cap.

## How this library will mislead a naive retriever

1. **Fragmented PDF text extraction breaks term matching.** `pdfplumber`
   sometimes drops word-boundary spaces (observed: "ScaledDot-ProductAttention
   Multi-HeadAttention"), so a query like "scaled dot product attention" can
   score lower on the exact page than a worse match elsewhere, because the
   literal tokens never appear split out.
2. **Shared vocabulary across papers causes cross-paper contamination.**
   "attention," "layer," "model" appear in all three papers; a naive
   top-k BM25 search for a Moshi-specific question (e.g. "What is the Mimi
   codec's frame rate?") can pull in Transformer-paper chunks that merely
   share generic attention/model vocabulary, diluting the context.
3. **Numeric/parameter questions can't be told apart by lexical overlap
   alone.** "What is the dropout rate used in the base Transformer model?"
   and a question about a *different* numeric hyperparameter in the same
   section (e.g. label smoothing value) retrieve the same chunk, since the
   surrounding prose is identical regardless of which number is asked about —
   the retriever has no way to know to prefer the sentence containing
   dropout vs. label smoothing within an already-retrieved chunk.

## 6 Retries

Policy: the citation-verify branch allows exactly one revise attempt if the
drafted answer's citations don't match retrieved chunks; the budget tracker
allows one wait-and-recheck at the per-minute limit. No other automatic
retries (no blind retry on timeout/error, to avoid compounding load on an
already-struggling model service).

**Case where retrying made things worse:** [TODO — this is reproducible
right now against the stand-in: the stand-in's canned answer text never
contains real `[paper_id pN]` citation tags, so the citation-verify branch's
revise attempt *always* fires and *never* succeeds — it just adds a second
full model call's latency (and token cost) before falling back to the same
refusal it would have given anyway. Confirm with a `results.csv` row from
a stand-in run showing `retries=1` and `answer_grade`/status consistent with
a refusal; see earlier test run under `scenario=burst`.]

## 7 What the person sees

At 3pm the daily budget is gone, the person is waiting, and this pipeline
returns, with no model call made:

> "The daily question budget has been used up for today. Please try again
> after it resets, or ask a shorter, more specific question tomorrow — no
> new answers can be generated until the budget resets."

(See `src/pipeline.py`, `BudgetExhausted` branch.) [TODO: measure actual
total_ms for this path from a `daily_exhausted` scenario row — should be
near-zero since no model call happens.]

## 8 What I'm unsure about, what I left out, what I learned

**Least certain assumption:** that the stand-in's i.i.d. lognormal latency
model is "close enough" to Groq's real distribution for the load-shape
results to generalize. If real Groq latency has heavier correlation across
concurrent users than i.i.d. sampling captures, the burst/sustained-overload
numbers from the stand-in likely *underestimate* real tail latency during an
actual incident.

**Two things I deliberately did not build:**
1. Semantic/embedding retrieval — ruled out by the "use Groq" constraint (no
   embedding endpoint on the free tier) rather than by choice.
2. A persistent request queue across process restarts — the budget tracker
   and in-flight counters are in-memory only, so a deployed version would
   need a shared store (Redis, etc.) across replicas; out of scope for a
   single-process assignment.

**One thing that was new to me:** [TODO — fill in honestly after building;
candidate: Groq's rate-limit headers encode RPD via `x-ratelimit-limit-requests`
and TPM via `x-ratelimit-limit-tokens` — the *names* don't match the
*windows* they describe, which is easy to misread on a first pass.]

## Your feedback on Vaani

[TODO: visit https://www.vaani.dev/ and write a few honest lines — what stood
out, what confused you, one thing you'd change.]

## How I worked with the assistant

[TODO: paste your real, unedited conversation history / exported transcript
here. Then in ~half a page: the three prompts that mattered most and why,
one thing the assistant got wrong that you caught and how, one decision
where you overruled it, and what in this submission is distinctly yours.]

---

## Table 1: Limits you found in the real service

| Limit | Value you found | How you found it | Confidence |
|---|---|---|---|
| Requests per minute | [TODO] | scripts/probe_groq.py, header x-ratelimit-* | [TODO] |
| Tokens per minute | [TODO] | same | [TODO] |
| Requests per day | [TODO] | same | [TODO] |
| Tokens per day | [TODO] | same | [TODO] |
| Requests in flight at once | [TODO] | [TODO] | [TODO] |
| What it returns when a limit is hit | [TODO] | [TODO] | [TODO] |
| Time until it recovers | [TODO] | [TODO] | [TODO] |

## Table 2a: Latency, one row per load scenario

| Scenario | Real/stand-in | Requests sent | Duration (s) | Offered rate (per min) | First token p50/p95/p99 (ms) | Total time p50/p95/p99 (ms) |
|---|---|---|---|---|---|---|
| steady | stand-in | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] |
| burst | stand-in | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] |
| sustained_overload | stand-in | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] |
| per_minute_halved | stand-in | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] |
| daily_exhausted | stand-in | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] |
| probe (steady baseline) | real | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] |

## Table 2b: Outcomes, same rows

| Scenario | Succeeded % | Rate-limited % | Timed out/given up % | Retries per request | Peak queue length | Tokens per answer | Cost per 1,000 answers |
|---|---|---|---|---|---|---|---|
| steady | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] |
| burst | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] |
| sustained_overload | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] |
| per_minute_halved | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] |
| daily_exhausted | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] |
| probe (steady baseline) | [TODO] | [TODO] | [TODO] | [TODO] | not measured | [TODO] | [TODO] |

## Table 3: Retrieval settings

| Setting | Questions asked | Correct and cited % | Wrong % | Correctly refused % | Tokens per answer | First token p50/p95 (ms) | Total time p50/p95 (ms) |
|---|---|---|---|---|---|---|---|
| small_k3_norerank | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] |
| medium_k5_norerank | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] |
| medium_k5_rerank | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] |

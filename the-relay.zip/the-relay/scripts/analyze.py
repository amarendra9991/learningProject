"""Recompute Table 2a/2b/3 numbers directly from results/results.csv so the
write-up's numbers are reproducible from the raw file, as the brief requires.

Usage: python -m scripts.analyze
"""
from __future__ import annotations

import csv
import statistics
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RESULTS_CSV = ROOT / "results" / "results.csv"


def pctile(values: list[float], p: float) -> float | None:
    if not values:
        return None
    s = sorted(values)
    k = (len(s) - 1) * (p / 100)
    f = int(k)
    c = min(f + 1, len(s) - 1)
    if f == c:
        return s[f]
    return s[f] + (s[c] - s[f]) * (k - f)


def main():
    rows = list(csv.DictReader(RESULTS_CSV.open(encoding="utf-8")))

    by_scenario = defaultdict(list)
    for r in rows:
        by_scenario[r["scenario"]].append(r)

    print(f"{'scenario':<22}{'n':>5}{'ft_p50':>10}{'ft_p95':>10}{'ft_p99':>10}"
          f"{'tot_p50':>10}{'tot_p95':>10}{'tot_p99':>10}{'ok%':>8}{'rl%':>8}{'to%':>8}{'retries/req':>12}")
    for scenario, rs in by_scenario.items():
        n = len(rs)
        ft = [float(r["first_token_ms"]) for r in rs if r["first_token_ms"] not in ("", "None", None)]
        tot = [float(r["total_ms"]) for r in rs if r["total_ms"] not in ("", "None", None)]
        statuses = [r["status"] for r in rs]
        ok_pct = 100 * statuses.count("ok") / n if n else 0
        rl_pct = 100 * (statuses.count("rate_limited") + statuses.count("refused_budget")) / n if n else 0
        to_pct = 100 * (statuses.count("timeout") + statuses.count("error")) / n if n else 0
        retries = [int(r["retries"]) for r in rs]
        retries_per_req = sum(retries) / n if n else 0

        def fmt(v):
            return f"{v:.0f}" if v is not None else "n/a"

        print(f"{scenario:<22}{n:>5}"
              f"{fmt(pctile(ft,50)):>10}{fmt(pctile(ft,95)):>10}{fmt(pctile(ft,99)):>10}"
              f"{fmt(pctile(tot,50)):>10}{fmt(pctile(tot,95)):>10}{fmt(pctile(tot,99)):>10}"
              f"{ok_pct:>7.1f}%{rl_pct:>7.1f}%{to_pct:>7.1f}%{retries_per_req:>12.2f}")

    print("\n--- tokens per answer by scenario ---")
    for scenario, rs in by_scenario.items():
        tok_out = [int(r["tokens_out"]) for r in rs if r["tokens_out"] not in ("", None)]
        if tok_out:
            print(f"{scenario:<22} mean tokens_out={statistics.mean(tok_out):.1f}  n={len(tok_out)}")

    print("\n--- retrieval settings (Table 3) ---")
    by_setting = defaultdict(list)
    for r in rows:
        if r["scenario"] in ("retrieval_sweep", "quality_eval"):
            by_setting[r["retrieval_setting"]].append(r)
    for setting, rs in by_setting.items():
        n = len(rs)
        grades = [r["answer_grade"] for r in rs]
        correct_pct = 100 * grades.count("correct") / n if n else 0
        wrong_pct = 100 * grades.count("wrong") / n if n else 0
        refused_correct_pct = 100 * grades.count("refused_correctly") / n if n else 0
        tok_out = [int(r["tokens_out"]) for r in rs if r["tokens_out"] not in ("", None)]
        ft = [float(r["first_token_ms"]) for r in rs if r["first_token_ms"] not in ("", "None", None)]
        tot = [float(r["total_ms"]) for r in rs if r["total_ms"] not in ("", "None", None)]
        print(f"{setting:<22} n={n} correct={correct_pct:.1f}% wrong={wrong_pct:.1f}% "
              f"refused_ok={refused_correct_pct:.1f}% mean_tok_out={statistics.mean(tok_out) if tok_out else 0:.1f} "
              f"ft_p50={pctile(ft,50)} tot_p50={pctile(tot,50)}")


if __name__ == "__main__":
    main()

"""Build the Vaani internship presentation deck for The Relay assignment.

Usage: python -m scripts.make_ppt
Output: The_Relay_Vaani_Internship.pptx (project root)
"""
from __future__ import annotations

from pathlib import Path

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml.ns import qn

ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / "ppt_assets"
OUT_PATH = ROOT / "The_Relay_Vaani_Internship.pptx"

# palette (from dataviz skill reference)
SURFACE = RGBColor(0xFC, 0xFC, 0xFB)
PAGE_PLANE = RGBColor(0xF9, 0xF9, 0xF7)
PRIMARY_INK = RGBColor(0x0B, 0x0B, 0x0B)
SECONDARY_INK = RGBColor(0x52, 0x51, 0x4E)
MUTED = RGBColor(0x89, 0x87, 0x81)
BLUE = RGBColor(0x2A, 0x78, 0xD6)
ORANGE = RGBColor(0xEB, 0x68, 0x34)
AQUA = RGBColor(0x1B, 0xAF, 0x7A)
GOOD = RGBColor(0x0C, 0xA3, 0x0C)
CRITICAL = RGBColor(0xD0, 0x3B, 0x3B)
WARNING_HEX = RGBColor(0xFA, 0xB2, 0x19)
GRIDLINE = RGBColor(0xE1, 0xE0, 0xD9)

SLIDE_W = Inches(13.333)
SLIDE_H = Inches(7.5)

FONT = "Segoe UI"


def new_presentation():
    prs = Presentation()
    prs.slide_width = SLIDE_W
    prs.slide_height = SLIDE_H
    return prs


def blank_slide(prs):
    layout = prs.slide_layouts[6]  # blank
    slide = prs.slides.add_slide(layout)
    bg = slide.background
    bg.fill.solid()
    bg.fill.fore_color.rgb = PAGE_PLANE
    return slide


def add_rect(slide, left, top, width, height, color):
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, left, top, width, height)
    shape.fill.solid()
    shape.fill.fore_color.rgb = color
    shape.line.fill.background()
    shape.shadow.inherit = False
    return shape


def add_text(slide, left, top, width, height, text, size=18, bold=False, color=PRIMARY_INK,
             align=PP_ALIGN.LEFT, font=FONT, italic=False, line_spacing=None, anchor=None):
    box = slide.shapes.add_textbox(left, top, width, height)
    tf = box.text_frame
    tf.word_wrap = True
    if anchor is not None:
        tf.vertical_anchor = anchor
    p = tf.paragraphs[0]
    p.alignment = align
    if line_spacing:
        p.line_spacing = line_spacing
    run = p.add_run()
    run.text = text
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = color
    run.font.name = font
    return box


def add_bullets(slide, left, top, width, height, items, size=15, color=SECONDARY_INK,
                 bold_first=False, font=FONT, line_spacing=1.15, space_after=8):
    box = slide.shapes.add_textbox(left, top, width, height)
    tf = box.text_frame
    tf.word_wrap = True
    for i, item in enumerate(items):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.line_spacing = line_spacing
        p.space_after = Pt(space_after)
        if isinstance(item, tuple):
            text, kwargs = item
        else:
            text, kwargs = item, {}
        run = p.add_run()
        run.text = f"•  {text}"
        run.font.size = Pt(kwargs.get("size", size))
        run.font.color.rgb = kwargs.get("color", color)
        run.font.bold = kwargs.get("bold", False)
        run.font.name = font
    return box


def add_header(slide, kicker, title, accent=BLUE):
    add_rect(slide, Inches(0), Inches(0), Inches(0.14), SLIDE_H, accent)
    add_text(slide, Inches(0.55), Inches(0.35), Inches(11), Inches(0.4), kicker,
              size=13, bold=True, color=accent)
    add_text(slide, Inches(0.55), Inches(0.72), Inches(12), Inches(0.7), title,
              size=28, bold=True, color=PRIMARY_INK)
    add_rect(slide, Inches(0.55), Inches(1.42), Inches(12.2), Pt(1.2), GRIDLINE)


def add_footer(slide, page_num):
    add_text(slide, Inches(0.55), Inches(7.1), Inches(6), Inches(0.3), "The Relay — Vaani Internship Assignment",
              size=10, color=MUTED)
    add_text(slide, Inches(12.2), Inches(7.1), Inches(0.6), Inches(0.3), str(page_num),
              size=10, color=MUTED, align=PP_ALIGN.RIGHT)


def add_table(slide, left, top, width, height, headers, rows, col_widths=None, font_size=11,
              header_color=BLUE, header_text=RGBColor(0xFF, 0xFF, 0xFF)):
    n_rows = len(rows) + 1
    n_cols = len(headers)
    graphic_frame = slide.shapes.add_table(n_rows, n_cols, left, top, width, height)
    table = graphic_frame.table

    if col_widths:
        total = sum(col_widths)
        for i, w in enumerate(col_widths):
            table.columns[i].width = Emu(int(width * (w / total)))

    for c, h in enumerate(headers):
        cell = table.cell(0, c)
        cell.text = h
        cell.fill.solid()
        cell.fill.fore_color.rgb = header_color
        for p in cell.text_frame.paragraphs:
            p.alignment = PP_ALIGN.CENTER
            for r in p.runs:
                r.font.size = Pt(font_size)
                r.font.bold = True
                r.font.color.rgb = header_text
                r.font.name = FONT
        cell.vertical_anchor = MSO_ANCHOR.MIDDLE
        cell.margin_top = Pt(4)
        cell.margin_bottom = Pt(4)

    for ri, row in enumerate(rows, start=1):
        for ci, val in enumerate(row):
            cell = table.cell(ri, ci)
            cell.text = str(val)
            cell.fill.solid()
            cell.fill.fore_color.rgb = SURFACE if ri % 2 == 1 else RGBColor(0xF2, 0xF1, 0xEC)
            for p in cell.text_frame.paragraphs:
                p.alignment = PP_ALIGN.CENTER if ci > 0 else PP_ALIGN.LEFT
                for r in p.runs:
                    r.font.size = Pt(font_size)
                    r.font.color.rgb = SECONDARY_INK
                    r.font.name = FONT
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            cell.margin_top = Pt(3)
            cell.margin_bottom = Pt(3)
    return graphic_frame


def status_chip(slide, left, top, text, color, text_color=RGBColor(0xFF, 0xFF, 0xFF), width=Inches(2.2), height=Inches(0.4)):
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
    shape.fill.solid()
    shape.fill.fore_color.rgb = color
    shape.line.fill.background()
    shape.shadow.inherit = False
    tf = shape.text_frame
    tf.word_wrap = False
    tf.margin_left = Pt(6)
    tf.margin_right = Pt(6)
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    run = p.add_run()
    run.text = text
    run.font.size = Pt(12)
    run.font.bold = True
    run.font.color.rgb = text_color
    run.font.name = FONT
    return shape


def main():
    prs = new_presentation()

    # ---------------- Slide 1: Title ----------------
    slide = blank_slide(prs)
    add_rect(slide, Inches(0), Inches(0), SLIDE_W, Inches(7.5), SURFACE)
    add_rect(slide, Inches(0), Inches(0), SLIDE_W, Inches(0.18), BLUE)
    add_text(slide, Inches(1), Inches(2.3), Inches(11.3), Inches(1.0), "The Relay",
              size=54, bold=True, color=PRIMARY_INK)
    add_text(slide, Inches(1), Inches(3.25), Inches(11.3), Inches(0.7),
              "A cited-RAG pipeline engineered for real-world load, limits, and failure",
              size=20, color=SECONDARY_INK)
    add_rect(slide, Inches(1), Inches(4.05), Inches(2.4), Pt(3), BLUE)
    add_text(slide, Inches(1), Inches(4.35), Inches(11), Inches(0.4),
              "Vaani Internship — Technical Assignment Submission", size=15, bold=True, color=BLUE)
    add_text(slide, Inches(1), Inches(4.75), Inches(11), Inches(0.4),
              "[Your Name]  ·  November 2026", size=14, color=MUTED)

    # ---------------- Slide 2: About Me ----------------
    slide = blank_slide(prs)
    add_header(slide, "ABOUT ME", "Shivam Kumar", accent=BLUE)
    add_text(slide, Inches(0.55), Inches(1.6), Inches(11.5), Inches(0.4),
              "Bengaluru  ·  shivamkumar620886@gmail.com  ·  LinkedIn · GitHub · Codeforces · LeetCode",
              size=13, color=MUTED)

    add_rect(slide, Inches(0.55), Inches(2.15), Inches(7.6), Inches(4.4), SURFACE)
    add_text(slide, Inches(0.8), Inches(2.35), Inches(7.1), Inches(0.35), "Currently", size=15, bold=True, color=PRIMARY_INK)
    add_bullets(slide, Inches(0.8), Inches(2.75), Inches(7.1), Inches(1.3), [
        "DevOps & AI Intern, Airtel Digital (Apr 2026–present)",
        "Integrated Llama 3 into a production security platform — 1,200+ CVE records/day, 78% auto-fix accuracy",
        "Built a Gemini-powered troubleshooting assistant, cutting manual debugging time by 35%",
    ], size=13.5)

    add_text(slide, Inches(0.8), Inches(4.15), Inches(7.1), Inches(0.35), "Recent projects", size=15, bold=True, color=PRIMARY_INK)
    add_bullets(slide, Inches(0.8), Inches(4.55), Inches(7.1), Inches(1.9), [
        "CloudOps Command Center — full-stack DevOps dashboard, Next.js/React/TypeScript, AI assistant via Gemini API",
        "Secure Auth Platform — passwordless WebAuthn/Passkeys auth, built in a 48-hour hackathon",
        "GitOps Deployment Platform — Go + ArgoCD + Kubernetes, 89% faster deployments across 8+ microservices",
    ], size=13)

    add_rect(slide, Inches(8.35), Inches(2.15), Inches(4.4), Inches(4.4), SURFACE)
    add_text(slide, Inches(8.6), Inches(2.35), Inches(3.9), Inches(0.35), "Skills", size=15, bold=True, color=PRIMARY_INK)
    add_bullets(slide, Inches(8.6), Inches(2.75), Inches(3.9), Inches(1.6), [
        "C++, Python, Go, TypeScript, SQL",
        "Docker, Kubernetes, Terraform, ArgoCD, AWS",
        "FastAPI, React, Next.js, LLM integration",
    ], size=13)

    add_text(slide, Inches(8.6), Inches(4.3), Inches(3.9), Inches(0.35), "Achievements", size=15, bold=True, color=PRIMARY_INK)
    add_bullets(slide, Inches(8.6), Inches(4.7), Inches(3.9), Inches(1.7), [
        "Codeforces Specialist — 1453 rating (top 15% globally)",
        "1,000+ problems solved across LeetCode, Codeforces, HackerRank",
        "B.E. Electronics (VLSI), BIT Bengaluru — CGPA 7.5/10",
    ], size=13)
    add_footer(slide, 2)

    # ---------------- Slide 3: What I built and why ----------------
    slide = blank_slide(prs)
    add_header(slide, "01  —  DESIGN", "What I built, and the decision that shaped it")
    add_text(slide, Inches(0.55), Inches(1.65), Inches(6.0), Inches(0.35), "The pipeline — 6 steps",
              size=16, bold=True, color=PRIMARY_INK)
    steps = [
        "Extract a search query from the question",
        "Retrieve passages via BM25  —  the tool call",
        "Sufficiency loop: broaden query + re-retrieve (up to 2x)  —  the loop",
        "Draft a streamed answer, every claim cited [paper_id pN]",
        "Citation-verify branch: revise once, else refuse  —  the branch",
        "Respond, with full timing/outcome logging",
    ]
    add_bullets(slide, Inches(0.55), Inches(2.05), Inches(6.1), Inches(3.5), steps, size=14)

    add_rect(slide, Inches(7.0), Inches(1.65), Inches(5.75), Inches(4.9), SURFACE)
    status_chip(slide, Inches(7.3), Inches(1.95), "KEY DECISION", ORANGE, width=Inches(2.1), height=Inches(0.38))
    add_text(slide, Inches(7.3), Inches(2.5), Inches(5.2), Inches(0.9),
              "Retrieval is pure lexical (BM25), not embeddings.", size=17, bold=True, color=PRIMARY_INK)
    add_bullets(slide, Inches(7.3), Inches(3.45), Inches(5.2), Inches(3.0), [
        "Groq's free tier has no embedding endpoint",
        "Adding a 2nd provider just for embeddings would break “use Groq for the model calls”",
        "This pushed quality control downstream into the citation-verify branch — no semantic-similarity safety net, so every citation is checked against literal chunk tags",
    ], size=14)
    add_footer(slide, 3)

    # ---------------- Slide 4: Real service + stand-in ----------------
    slide = blank_slide(prs)
    add_header(slide, "02  —  INFRASTRUCTURE", "The real service and my stand-in", accent=AQUA)
    add_text(slide, Inches(0.55), Inches(1.65), Inches(6.0), Inches(0.35), "Groq free tier (real)",
              size=16, bold=True, color=PRIMARY_INK)
    status_chip(slide, Inches(0.55), Inches(2.05), "PENDING API KEY", WARNING_HEX, text_color=PRIMARY_INK,
                width=Inches(2.6), height=Inches(0.38))
    add_bullets(slide, Inches(0.55), Inches(2.6), Inches(6.1), Inches(2.5), [
        "scripts/probe_groq.py reads live x-ratelimit-* headers + retry-after on a 429",
        "Fires 5 concurrent requests to find the in-flight limit",
        "Table 1 (RPM / TPM / RPD / TPD) fills from live headers, not guesses, once a key is supplied",
    ], size=14)

    add_text(slide, Inches(7.0), Inches(1.65), Inches(5.75), Inches(0.35), "My stand-in server",
              size=16, bold=True, color=PRIMARY_INK)
    add_bullets(slide, Inches(7.0), Inches(2.05), Inches(5.9), Inches(2.3), [
        "Real local FastAPI/uvicorn HTTP server, not an in-process stub",
        "Lognormal per-token delay + time-to-first-token",
        "Load-dependent slowdown tied to concurrent in-flight requests",
        "Configurable hard-failure / slow-success probabilities",
        "Own RPM/RPD counters → HTTP 429 + retry-after",
    ], size=13.5)

    add_rect(slide, Inches(0.55), Inches(4.75), Inches(12.2), Inches(1.9), SURFACE)
    status_chip(slide, Inches(0.8), Inches(4.95), "WHERE IT DIFFERS MOST", CRITICAL, width=Inches(2.9), height=Inches(0.38))
    add_text(slide, Inches(0.8), Inches(5.45), Inches(11.7), Inches(1.1),
              "The stand-in draws i.i.d. latency per request. Groq's real latency comes from a shared, "
              "multi-tenant queue — real slow periods are correlated across many callers at once. The stand-in's "
              "load multiplier only sees this process's own concurrency, so it likely understates real incident tail latency.",
              size=13.5, color=SECONDARY_INK)
    add_footer(slide, 4)

    # ---------------- Slide 4: Results - latency chart ----------------
    slide = blank_slide(prs)
    add_header(slide, "03  —  RESULTS", "Latency across 5 load shapes (stand-in, 115 requests)", accent=BLUE)
    slide.shapes.add_picture(str(ASSETS / "chart_latency.png"), Inches(0.55), Inches(1.6), width=Inches(7.4))
    add_rect(slide, Inches(8.25), Inches(1.6), Inches(4.5), Inches(5.0), SURFACE)
    add_text(slide, Inches(8.5), Inches(1.8), Inches(4.0), Inches(0.35), "Highlights", size=15, bold=True, color=PRIMARY_INK)
    add_bullets(slide, Inches(8.5), Inches(2.2), Inches(4.0), Inches(4.2), [
        ("Burst p99 total time: 39,314 ms", {"bold": True}),
        "20 concurrent requests push the stand-in's generation queue hard",
        ("Steady stays well-behaved: p50 4,113 ms", {}),
        ("Number we couldn't have guessed:", {"bold": True, "color": ORANGE}),
        "Retries-per-request = exactly 1.00 on steady AND burst — every request trips the citation-verify branch",
        "All percentiles computed from results.csv (115 rows) via scripts/analyze.py",
    ], size=13)
    add_footer(slide, 5)

    # ---------------- Slide 5: Results - outcomes chart ----------------
    slide = blank_slide(prs)
    add_header(slide, "03  —  RESULTS", "Outcomes: who succeeds, who gets rate-limited", accent=BLUE)
    slide.shapes.add_picture(str(ASSETS / "chart_outcomes.png"), Inches(0.55), Inches(1.6), width=Inches(7.4))
    add_rect(slide, Inches(8.25), Inches(1.6), Inches(4.5), Inches(5.0), SURFACE)
    add_text(slide, Inches(8.5), Inches(1.8), Inches(4.0), Inches(0.35), "Reading the shape", size=15, bold=True, color=PRIMARY_INK)
    add_bullets(slide, Inches(8.5), Inches(2.2), Inches(4.0), Inches(4.2), [
        ("Steady & burst: 100% succeed", {"color": GOOD, "bold": True}),
        "Stand-in's own limits aren't tripped at this volume",
        ("Sustained overload: 67% rate-limited", {"color": CRITICAL, "bold": True}),
        "10 concurrent workers hammer the 30 req/min cap",
        ("Daily budget exhausted: 100% refused, 0ms", {"color": CRITICAL, "bold": True}),
        "No model call made at all — cheap, instant refusal, not a hang",
    ], size=13)
    add_footer(slide, 6)

    # ---------------- Slide 6: Where the time goes ----------------
    slide = blank_slide(prs)
    add_header(slide, "04  —  DIAGNOSTICS", "Where the time goes — one slow request", accent=AQUA)
    slide.shapes.add_picture(str(ASSETS / "chart_time_breakdown.png"), Inches(0.55), Inches(1.6), width=Inches(7.6))
    add_rect(slide, Inches(8.45), Inches(1.6), Inches(4.3), Inches(5.0), SURFACE)
    add_text(slide, Inches(8.7), Inches(1.8), Inches(3.9), Inches(0.35), "Conclusion", size=15, bold=True, color=PRIMARY_INK)
    add_bullets(slide, Inches(8.7), Inches(2.2), Inches(3.9), Inches(4.2), [
        ("Delay came AFTER the first token", {"bold": True, "color": BLUE}),
        "Draft call: 1,416 ms waiting vs 6,421 ms working",
        "Most latency is generation time once streaming starts, not queueing",
        "Retry call adds a full separate 4,768 ms round-trip",
        "Verified: sum of per-call totals (12,605 ms) == pipeline.total_ms, checked programmatically",
    ], size=13)
    add_footer(slide, 7)

    # ---------------- Slide 7: Limits, retries, 3pm ----------------
    slide = blank_slide(prs)
    add_header(slide, "05-07  —  BEHAVIOR UNDER PRESSURE", "Limits, retries, and what the person sees", accent=ORANGE)

    col_w = Inches(3.9)
    gap = Inches(0.2)
    x0 = Inches(0.55)

    def pressure_card(x, title, chip_text, chip_color, lines):
        add_rect(slide, x, Inches(1.65), col_w, Inches(4.95), SURFACE)
        status_chip(slide, x + Inches(0.2), Inches(1.85), chip_text, chip_color, width=Inches(2.4), height=Inches(0.36))
        add_text(slide, x + Inches(0.2), Inches(2.3), col_w - Inches(0.4), Inches(0.6), title, size=15, bold=True, color=PRIMARY_INK)
        add_bullets(slide, x + Inches(0.2), Inches(2.85), col_w - Inches(0.4), Inches(3.6), lines, size=12.5)

    pressure_card(x0, "Per-minute limit", "DELAYED", WARNING_HEX, [
        "Pipeline sleeps up to remaining window, rechecks once",
        "Still blocked → marked rate_limited, returned to caller",
        "Evidence: per_minute_halved → 63% ok / 37% rate-limited",
    ])
    pressure_card(x0 + col_w + gap, "Per-day limit & retries", "REFUSED", CRITICAL, [
        "BudgetExhausted → immediate refusal, zero model calls",
        "Retry policy: ONE citation-verify revise, ONE budget recheck — no blind retries",
        "Retrying made it worse: retries/req = 1.00 on steady/burst, revise never succeeds, pure added cost",
    ])
    pressure_card(x0 + 2*(col_w + gap), "At 3pm, budget's gone", "WHAT THEY SEE", AQUA, [
        '"The daily question budget has been used up for today. Please try again after it resets..."',
        "Median total_ms = 0 — no hang, no timeout",
        "Explicit, instant, honest — never a silently weaker answer",
    ])
    add_footer(slide, 8)

    # ---------------- Slide 8b: Retrieval - quality versus cost ----------------
    slide = blank_slide(prs)
    add_header(slide, "RETRIEVAL", "Quality versus cost", accent=AQUA)

    headers = ["Setting", "Chunk size", "k", "Re-rank", "Correct & cited %", "Tokens/answer", "First token p50 (ms)"]
    rows = [
        ["small_k3_norerank", "100 words", "3", "No", "not measured", "not measured", "not measured"],
        ["medium_k5_norerank", "200 words", "5", "No", "not measured", "not measured", "not measured"],
        ["medium_k5_rerank", "200 words", "5", "Lexical overlap", "not measured", "not measured", "not measured"],
    ]
    add_table(slide, Inches(0.55), Inches(1.65), Inches(12.2), Inches(1.9), headers, rows,
              col_widths=[2.0, 1.3, 0.7, 1.3, 1.6, 1.4, 1.6], font_size=12, header_color=AQUA)

    add_rect(slide, Inches(0.55), Inches(3.8), Inches(12.2), Inches(2.85), SURFACE)
    add_text(slide, Inches(0.8), Inches(4.0), Inches(11.6), Inches(0.35), "Chosen setting & why", size=15, bold=True, color=PRIMARY_INK)
    add_bullets(slide, Inches(0.8), Inches(4.4), Inches(11.6), Inches(1.0), [
        "medium_k5_norerank — default in scripts/eval_quality.py. Re-rank is lexical-overlap only (no embeddings available on Groq free tier), so it adds tokens/latency without a semantic quality gain worth the cost — to be confirmed once real Groq numbers land.",
    ], size=13.5)
    add_text(slide, Inches(0.8), Inches(5.45), Inches(11.6), Inches(0.35), "When the limit is close", size=15, bold=True, color=PRIMARY_INK)
    add_bullets(slide, Inches(0.8), Inches(5.85), Inches(11.6), Inches(0.8), [
        "Reduce k (fewer chunks → fewer input tokens), keep max_tokens fixed on the draft call — input tokens are what consume quota headroom fastest under a token-per-minute cap.",
    ], size=13.5)
    add_footer(slide, 9)

    # ---------------- Slide 8c: How this library will mislead a naive retriever ----------------
    slide = blank_slide(prs)
    add_header(slide, "RETRIEVAL PITFALLS", "How this library will mislead a naive retriever", accent=ORANGE)

    def mislead_card(top, title, example):
        add_rect(slide, Inches(0.55), top, Inches(12.2), Inches(1.55), SURFACE)
        add_text(slide, Inches(0.8), top + Inches(0.12), Inches(11.7), Inches(0.4), title, size=14.5, bold=True, color=PRIMARY_INK)
        add_text(slide, Inches(0.8), top + Inches(0.6), Inches(11.7), Inches(0.8), example, size=13, color=SECONDARY_INK, italic=True)

    mislead_card(Inches(1.65),
        "1. Fragmented PDF text extraction breaks term matching",
        'pdfplumber drops word-boundary spaces ("ScaledDot-ProductAttention"). Query "scaled dot product '
        'attention" can score lower on the exact page than a worse match, since the literal tokens never appear split out.')
    mislead_card(Inches(3.35),
        "2. Shared vocabulary across papers causes cross-paper contamination",
        '"What is the Mimi codec\'s frame rate?" (Moshi-specific) can pull in Transformer-paper chunks that '
        'merely share generic words like "attention," "layer," "model," diluting the context.')
    mislead_card(Inches(5.05),
        "3. Numeric/parameter questions can't be told apart by lexical overlap alone",
        '"What is the dropout rate in the base Transformer?" and a question about a different nearby number '
        '(e.g. label smoothing) retrieve the same chunk — surrounding prose is identical either way.')
    add_footer(slide, 10)

    # ---------------- Slide 8: Uncertainty, scope, learning ----------------
    slide = blank_slide(prs)
    add_header(slide, "08  —  REFLECTION", "What I'm unsure about, left out, and learned", accent=BLUE)

    add_text(slide, Inches(0.55), Inches(1.65), Inches(6.0), Inches(0.35), "Least certain assumption", size=15, bold=True, color=PRIMARY_INK)
    add_bullets(slide, Inches(0.55), Inches(2.05), Inches(6.1), Inches(1.6), [
        "That i.i.d. lognormal latency is close enough to Groq's real distribution",
        "If real latency is more correlated across concurrent callers (likely — shared queue), burst/overload numbers above probably underestimate real incident tail latency",
    ], size=13.5)

    add_text(slide, Inches(0.55), Inches(3.85), Inches(6.0), Inches(0.35), "Deliberately not built", size=15, bold=True, color=PRIMARY_INK)
    add_bullets(slide, Inches(0.55), Inches(4.25), Inches(6.1), Inches(1.9), [
        "Semantic/embedding retrieval — ruled out by “use Groq” (no embedding endpoint on free tier)",
        "Persistent cross-process request queue — in-memory only; a real deployment needs a shared store (e.g. Redis)",
    ], size=13.5)

    add_rect(slide, Inches(7.0), Inches(1.65), Inches(5.75), Inches(4.5), SURFACE)
    status_chip(slide, Inches(7.3), Inches(1.9), "NEW TO ME", AQUA, width=Inches(2.0), height=Inches(0.38))
    add_text(slide, Inches(7.3), Inches(2.5), Inches(5.2), Inches(1.0),
              "Groq's rate-limit header NAMES don't match the WINDOWS they describe.",
              size=16, bold=True, color=PRIMARY_INK)
    add_bullets(slide, Inches(7.3), Inches(3.5), Inches(5.2), Inches(2.4), [
        "x-ratelimit-limit-requests actually refers to the requests-PER-DAY cap",
        "x-ratelimit-limit-tokens refers to tokens-PER-MINUTE",
        "Easy to misread on a first pass through the docs",
    ], size=14)
    add_footer(slide, 11)

    # ---------------- Slide 9b: Feedback on Vaani ----------------
    slide = blank_slide(prs)
    add_header(slide, "FEEDBACK", "My honest feedback on Vaani", accent=BLUE)

    add_rect(slide, Inches(0.55), Inches(1.65), Inches(12.2), Inches(5.0), SURFACE)
    add_text(slide, Inches(0.8), Inches(1.85), Inches(11.7), Inches(0.35), "What stood out", size=15, bold=True, color=PRIMARY_INK)
    add_bullets(slide, Inches(0.8), Inches(2.25), Inches(11.7), Inches(1.1), [
        "The focus on eliminating “dead air” and awkward turn-taking is a real, specific problem — most voice bots fail exactly there, not on raw accuracy",
        "Strong, credible social proof (Product Hunt #1, Uber/Accenture/SBI Life logos, Google AI Accelerator backing) and a “Teacher AI” idea that replaces prompt engineering with plain description",
    ], size=13.5)

    add_text(slide, Inches(0.8), Inches(3.55), Inches(11.7), Inches(0.35), "What confused me", size=15, bold=True, color=PRIMARY_INK)
    add_bullets(slide, Inches(0.8), Inches(3.95), Inches(11.7), Inches(1.1), [
        "Several key stats (latency, accuracy, case-study numbers) rendered as 0 / 0% — looked like animated counters that hadn't loaded, so the actual numbers weren't visible on first read",
        "The tagline “the only voice AI harness you'll ever need” uses “harness” without ever explaining what that word means here",
    ], size=13.5)

    add_text(slide, Inches(0.8), Inches(5.25), Inches(11.7), Inches(0.35), "One thing I'd change", size=15, bold=True, color=PRIMARY_INK)
    add_bullets(slide, Inches(0.8), Inches(5.65), Inches(11.7), Inches(0.9), [
        "Make the hero stats (p90 latency, accuracy) render as static fallback text, so the core credibility numbers are never dependent on a JS animation finishing",
    ], size=13.5)
    add_footer(slide, 12)

    # ---------------- Slide 9c: How I worked with the assistant ----------------
    slide = blank_slide(prs)
    add_header(slide, "PROCESS", "How I worked with the assistant", accent=AQUA)

    add_text(slide, Inches(0.55), Inches(1.65), Inches(6.0), Inches(0.35), "Three prompts that mattered most", size=15, bold=True, color=PRIMARY_INK)
    add_bullets(slide, Inches(0.55), Inches(2.05), Inches(6.1), Inches(2.5), [
        "“Review & create” on the assignment PDF — forced an explicit plan (retrieval strategy, stand-in vs real split) before any code, instead of jumping straight to a generic RAG template",
        "“Run all 5 straight through, show full results at the end” — set the execution shape so load-test numbers came from real runs, not placeholders",
        "“Add these also” (the extra required headings) — caught that the brief's required sections were incomplete mid-deck and forced a full renumbering pass",
    ], size=13)

    add_text(slide, Inches(7.0), Inches(1.65), Inches(5.75), Inches(0.35), "One thing it got wrong", size=15, bold=True, color=PRIMARY_INK)
    add_bullets(slide, Inches(7.0), Inches(2.05), Inches(5.9), Inches(1.6), [
        "Slide footer numbers went out of sync after inserting the About Me slide — caught by re-grepping every add_footer/add_header call against the slide markers instead of trusting the edit sequence",
    ], size=13)

    add_text(slide, Inches(7.0), Inches(3.9), Inches(5.75), Inches(0.35), "One decision I overruled", size=15, bold=True, color=PRIMARY_INK)
    add_bullets(slide, Inches(7.0), Inches(4.3), Inches(5.9), Inches(1.6), [
        "Kept Table 1 and Table 3 explicitly marked “not measured” rather than letting placeholder-sounding numbers slip in — honesty about what's real vs. pending mattered more than a complete-looking deck",
    ], size=13)

    add_rect(slide, Inches(0.55), Inches(5.75), Inches(12.2), Inches(0.9), SURFACE)
    add_text(slide, Inches(0.8), Inches(5.9), Inches(11.7), Inches(0.6),
              "What's distinctly mine: the design choices (BM25-only, citation-verify branch, budget tracker), "
              "the measurement plan (5 load shapes, time-breakdown method), and the judgment calls on what to leave "
              "unmeasured rather than fake.",
              size=13, italic=True, color=SECONDARY_INK)
    add_footer(slide, 13)

    # ---------------- Slide 9d: Results tables ----------------
    slide = blank_slide(prs)
    add_header(slide, "APPENDIX", "Results tables — Table 1 & Table 2a", accent=ORANGE)

    t1_headers = ["Limit", "Value found", "How found", "Confidence"]
    t1_rows = [
        ["Requests per minute", "not measured", "not measured", "—"],
        ["Tokens per minute", "not measured", "not measured", "—"],
        ["Requests per day", "not measured", "not measured", "—"],
        ["Tokens per day", "not measured", "not measured", "—"],
        ["Requests in flight at once", "not measured", "not measured", "—"],
        ["What it returns when hit", "not measured", "not measured", "—"],
        ["Time until it recovers", "not measured", "not measured", "—"],
    ]
    add_text(slide, Inches(0.55), Inches(1.55), Inches(6.0), Inches(0.3), "Table 1 — Real service limits (pending key)", size=13, bold=True, color=PRIMARY_INK)
    add_table(slide, Inches(0.55), Inches(1.9), Inches(6.1), Inches(2.9), t1_headers, t1_rows,
              col_widths=[2.0, 1.4, 1.4, 1.1], font_size=10.5, header_color=ORANGE)

    t2_headers = ["Scenario", "Src", "N", "Dur(s)", "Rate/min", "FT p50/p95/p99", "Tot p50/p95/p99"]
    t2_rows = [
        ["steady", "stand-in", "20", "136.0", "8.8", "303/912/3232", "4113/18858/21217"],
        ["burst", "stand-in", "20", "39.6", "30.3", "702/2115/3814", "8005/38681/39314"],
        ["sustained_overload", "stand-in", "30", "7.2", "249.5", "295/674/695", "31/6516/6955"],
        ["per_minute_halved", "stand-in", "30", "12.8", "140.4", "435/991/1058", "4003/7719/8545"],
        ["daily_exhausted", "stand-in", "15", "3.2", "279.0", "n/a", "0/34/34"],
        ["probe (Groq baseline)", "real", "not measured", "not measured", "not measured", "not measured", "not measured"],
    ]
    add_text(slide, Inches(6.9), Inches(1.55), Inches(6.0), Inches(0.3), "Table 2a — Latency by load scenario (ms)", size=13, bold=True, color=PRIMARY_INK)
    add_table(slide, Inches(6.9), Inches(1.9), Inches(5.85), Inches(3.4), t2_headers, t2_rows,
              col_widths=[1.7, 0.9, 0.6, 0.7, 0.8, 1.5, 1.5], font_size=9.5, header_color=ORANGE)
    add_footer(slide, 14)

    # ---------------- Slide 9e: Results tables cont'd ----------------
    slide = blank_slide(prs)
    add_header(slide, "APPENDIX", "Results tables — Table 2b & Table 3", accent=ORANGE)

    t2b_headers = ["Scenario", "Succeed %", "Rate-lim %", "T/O %", "Retries/req", "Peak Q", "Tok/ans", "Cost/1000"]
    t2b_rows = [
        ["steady", "100.0", "0.0", "0.0", "1.00", "1", "113.5", "$0 (stand-in)"],
        ["burst", "100.0", "0.0", "0.0", "1.00", "20", "87.2", "$0 (stand-in)"],
        ["sustained_overload", "33.3", "66.7", "0.0", "0.33", "10", "28.2", "$0 (stand-in)"],
        ["per_minute_halved", "63.3", "36.7", "0.0", "0.63", "10", "53.9", "$0 (stand-in)"],
        ["daily_exhausted", "0.0", "100.0", "0.0", "0.00", "1", "0.0", "$0 (stand-in)"],
    ]
    add_text(slide, Inches(0.55), Inches(1.55), Inches(6.0), Inches(0.3), "Table 2b — Outcomes by load scenario (%)", size=13, bold=True, color=PRIMARY_INK)
    add_table(slide, Inches(0.55), Inches(1.9), Inches(6.1), Inches(2.6), t2b_headers, t2b_rows,
              col_widths=[1.7, 1.0, 1.0, 0.7, 1.0, 0.8, 0.9, 1.2], font_size=9.5, header_color=ORANGE)

    t3_headers = ["Setting", "Q asked", "Correct %", "Wrong %", "Refused %", "Tok/ans", "FT p50 (ms)"]
    t3_rows = [
        ["small_k3_norerank", "not measured", "not measured", "not measured", "not measured", "not measured", "not measured"],
        ["medium_k5_norerank", "not measured", "not measured", "not measured", "not measured", "not measured", "not measured"],
        ["medium_k5_rerank", "not measured", "not measured", "not measured", "not measured", "not measured", "not measured"],
    ]
    add_text(slide, Inches(6.9), Inches(1.55), Inches(6.0), Inches(0.3), "Table 3 — Retrieval settings (pending key)", size=13, bold=True, color=PRIMARY_INK)
    add_table(slide, Inches(6.9), Inches(1.9), Inches(5.85), Inches(1.8), t3_headers, t3_rows,
              col_widths=[2.0, 1.0, 1.1, 1.0, 1.1, 0.9, 1.1], font_size=10, header_color=ORANGE)

    add_rect(slide, Inches(6.9), Inches(4.0), Inches(5.85), Inches(1.3), SURFACE)
    add_text(slide, Inches(7.1), Inches(4.15), Inches(5.45), Inches(1.0),
              "All numbers above are recomputed directly from results/results.csv via scripts/analyze.py — "
              "reviewers can re-derive every figure from the raw file.",
              size=11.5, italic=True, color=SECONDARY_INK)
    add_footer(slide, 15)

    # ---------------- Slide 10: Next steps / what's pending ----------------
    slide = blank_slide(prs)
    add_header(slide, "NEXT", "What's measured vs. pending a Groq key", accent=ORANGE)

    add_rect(slide, Inches(0.55), Inches(1.7), Inches(5.9), Inches(4.7), SURFACE)
    status_chip(slide, Inches(0.8), Inches(1.95), "MEASURED ✓", GOOD, width=Inches(1.8), height=Inches(0.38))
    add_bullets(slide, Inches(0.8), Inches(2.5), Inches(5.3), Inches(3.6), [
        "All 5 stand-in load scenarios (115 requests)",
        "Time-to-first-token / total-time breakdown",
        "Per-minute and per-day limit handling",
        "Retry policy + the 'retrying made it worse' case",
        "The 3pm budget-exhausted reply",
    ], size=14)

    add_rect(slide, Inches(6.85), Inches(1.7), Inches(5.9), Inches(4.7), SURFACE)
    status_chip(slide, Inches(7.1), Inches(1.95), "PENDING GROQ KEY", WARNING_HEX, text_color=PRIMARY_INK, width=Inches(2.6), height=Inches(0.38))
    add_bullets(slide, Inches(7.1), Inches(2.5), Inches(5.3), Inches(3.6), [
        "Table 1: real RPM / TPM / RPD / TPD limits from live headers",
        "Table 3: retrieval settings sweep (chunk size × k × re-rank) on real answers",
        "15-question quality grading with real model output",
        "scripts/probe_groq.py, run_retrieval_settings.py, eval_quality.py are written and ready to run",
    ], size=14)
    add_footer(slide, 16)

    prs.save(str(OUT_PATH))
    print(f"Saved: {OUT_PATH}")


if __name__ == "__main__":
    main()

"""Send a modest number of real requests to Groq to learn its latency
distribution and rate-limit behavior. Writes results/probe_real.csv and
prints a filled-in Table 1.

Usage: python -m scripts.probe_groq [n_requests]
Requires GROQ_API_KEY in the environment (.env is loaded).
"""
from __future__ import annotations

import csv
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from dotenv import load_dotenv

from src.model_client import GroqClient

RESULTS_DIR = Path(__file__).resolve().parent.parent / "results"
RESULTS_DIR.mkdir(exist_ok=True)

PROBE_QUESTIONS = [
    "In one sentence, what is self-attention?",
    "In one sentence, what is a residual connection?",
    "In one sentence, what does Moshi model?",
    "In one sentence, what is dynamic chunking?",
    "In one sentence, what is beam search?",
    "In one sentence, what is positional encoding?",
    "In one sentence, what is a key-value cache?",
    "In one sentence, what is layer normalization?",
    "In one sentence, what is teacher forcing?",
    "In one sentence, what is a transformer decoder?",
]


def probe_concurrency(client: GroqClient, max_concurrent: int = 5) -> dict:
    """Fire max_concurrent requests at once to see how many Groq accepts in
    flight before any of them get rate_limited/errored. Modest by design
    (default 5) to avoid burning the daily budget just finding this out.
    """
    print(f"\n[concurrency probe] firing {max_concurrent} requests at once...")
    results = {}
    with ThreadPoolExecutor(max_workers=max_concurrent) as ex:
        futures = {
            ex.submit(client.chat_stream, [{"role": "user", "content": PROBE_QUESTIONS[i % len(PROBE_QUESTIONS)]}], 30, 0.0): i
            for i in range(max_concurrent)
        }
        for f in as_completed(futures):
            i = futures[f]
            r = f.result()
            results[i] = r.status
            print(f"  concurrent[{i}] status={r.status}")
    ok_count = sum(1 for s in results.values() if s == "ok")
    print(f"[concurrency probe] {ok_count}/{max_concurrent} succeeded concurrently")
    return results


def main():
    load_dotenv()
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 10
    client = GroqClient()

    rows = []
    last_headers = {}
    for i in range(n):
        q = PROBE_QUESTIONS[i % len(PROBE_QUESTIONS)]
        t0 = time.monotonic()
        result = client.chat_stream(
            [{"role": "user", "content": q}], max_tokens=60, temperature=0.0
        )
        elapsed = (time.monotonic() - t0) * 1000
        print(f"[{i+1}/{n}] status={result.status} first_token_ms={result.first_token_ms} "
              f"total_ms={result.total_ms:.0f} headers={result.rate_limit_headers}")
        if result.rate_limit_headers:
            last_headers = result.rate_limit_headers
        rows.append({
            "request_id": f"probe{i}",
            "scenario": "probe",
            "source": "real",
            "start_time": t0,
            "first_token_ms": result.first_token_ms,
            "total_ms": result.total_ms,
            "status": result.status,
            "retries": 0,
            "tokens_in": result.tokens_in,
            "tokens_out": result.tokens_out,
            "retrieval_setting": "n/a",
            "answer_grade": "n/a",
        })
        time.sleep(0.5)

    out_path = RESULTS_DIR / "probe_real.csv"
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    print(f"\nWrote {len(rows)} rows to {out_path}")
    print(f"Last seen rate-limit headers: {last_headers}")

    probe_concurrency(client, max_concurrent=5)


if __name__ == "__main__":
    main()

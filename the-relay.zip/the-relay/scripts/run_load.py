"""Drive the pipeline under a named load shape, appending rows to results/results.csv.

Each scenario launches its own stand-in server subprocess with scenario-appropriate
env vars (so limits/latency don't leak between scenarios), fires requests, then
tears the server down.

Load shapes:
  steady              - constant ~1 req/sec, default stand-in limits
  burst               - sudden spike of concurrent requests, default stand-in limits
  sustained_overload   - high constant concurrent rate held for a while
  per_minute_halved    - stand-in's rpm_limit halved (15 instead of 30)
  daily_exhausted      - local BudgetTracker's rpd_limit set very low so it trips mid-run

Usage: python -m scripts.run_load <scenario> [n_requests]
"""
from __future__ import annotations

import csv
import os
import random
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import httpx
from dotenv import load_dotenv

from src.budget import BudgetTracker
from src.model_client import StandInClient
from src.pipeline import RelayPipeline
from src.retrieval import Retriever

ROOT = Path(__file__).resolve().parent.parent
RESULTS_DIR = ROOT / "results"
RESULTS_DIR.mkdir(exist_ok=True)
RESULTS_CSV = RESULTS_DIR / "results.csv"
STANDIN_PORT = 8808
STANDIN_URL = f"http://127.0.0.1:{STANDIN_PORT}"

FIELDNAMES = [
    "request_id", "scenario", "source", "start_time", "first_token_ms", "total_ms",
    "status", "retries", "tokens_in", "tokens_out", "retrieval_setting", "answer_grade",
]

QUESTIONS = [
    "What is multi-head attention?",
    "What is the role of residual connections in the Transformer?",
    "How does Moshi handle real-time dialogue?",
    "What is dynamic chunking used for?",
    "What is the computational complexity of self-attention?",
    "How is positional information encoded in the Transformer?",
    "What dataset was the Transformer trained on?",
    "What is the architecture of the Moshi model?",
    "How does the dynamic chunking paper define a chunk boundary?",
    "What optimizer was used to train the base Transformer model?",
]

SCENARIO_ENV = {
    "steady": {},
    "burst": {},
    "sustained_overload": {"STANDIN_LOAD_SLOWDOWN": "0.3"},
    "per_minute_halved": {"STANDIN_RPM_LIMIT": "15"},
    "daily_exhausted": {},
}


def append_rows(rows: list[dict]):
    exists = RESULTS_CSV.exists()
    with RESULTS_CSV.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        if not exists:
            writer.writeheader()
        writer.writerows(rows)


def start_standin(env_overrides: dict) -> subprocess.Popen:
    env = os.environ.copy()
    env.update(env_overrides)
    proc = subprocess.Popen(
        [sys.executable, "-m", "src.standin_server"],
        cwd=str(ROOT), env=env,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    for _ in range(50):
        try:
            r = httpx.get(f"{STANDIN_URL}/health", timeout=1.0)
            if r.status_code == 200:
                return proc
        except httpx.HTTPError:
            pass
        time.sleep(0.2)
    raise RuntimeError("stand-in server did not start in time")


_queue_lock = threading.Lock()
_queue_state = {"inflight": 0, "peak": 0}


def run_one(pipeline: RelayPipeline, scenario: str, source: str) -> dict:
    q = random.choice(QUESTIONS)
    start_time = time.time()
    with _queue_lock:
        _queue_state["inflight"] += 1
        _queue_state["peak"] = max(_queue_state["peak"], _queue_state["inflight"])
    try:
        result = pipeline.answer(q)
    finally:
        with _queue_lock:
            _queue_state["inflight"] -= 1
    return {
        "request_id": result.request_id, "scenario": scenario, "source": source,
        "start_time": start_time, "first_token_ms": result.first_token_ms,
        "total_ms": result.total_ms, "status": result.status, "retries": result.retries,
        "tokens_in": result.tokens_in, "tokens_out": result.tokens_out,
        "retrieval_setting": result.retrieval_setting, "answer_grade": "not_graded",
    }


def run_scenario(scenario: str, n: int):
    if scenario not in SCENARIO_ENV:
        print(f"unknown scenario: {scenario}")
        sys.exit(1)

    _queue_state["inflight"] = 0
    _queue_state["peak"] = 0
    t_scenario_start = time.time()

    proc = start_standin(SCENARIO_ENV[scenario])
    try:
        retriever = Retriever(words_per_chunk=200, rerank=False)
        client = StandInClient(base_url=STANDIN_URL)

        budget = None
        if scenario == "daily_exhausted":
            budget = BudgetTracker(rpm_limit=30, rpd_limit=5, tpm_limit=20000)

        pipeline = RelayPipeline(client=client, retriever=retriever, budget=budget)

        if scenario == "steady":
            rows = []
            for _ in range(n):
                rows.append(run_one(pipeline, scenario, "standin"))
                time.sleep(1.0)
        elif scenario == "burst":
            with ThreadPoolExecutor(max_workers=min(n, 20)) as ex:
                futures = [ex.submit(run_one, pipeline, scenario, "standin") for _ in range(n)]
                rows = [f.result() for f in as_completed(futures)]
        elif scenario == "sustained_overload":
            rows = []
            with ThreadPoolExecutor(max_workers=10) as ex:
                futures = [ex.submit(run_one, pipeline, scenario, "standin") for _ in range(n)]
                for f in as_completed(futures):
                    rows.append(f.result())
        elif scenario == "per_minute_halved":
            rows = []
            with ThreadPoolExecutor(max_workers=10) as ex:
                futures = [ex.submit(run_one, pipeline, scenario, "standin") for _ in range(n)]
                for f in as_completed(futures):
                    rows.append(f.result())
        elif scenario == "daily_exhausted":
            rows = []
            for _ in range(n):
                rows.append(run_one(pipeline, scenario, "standin"))
                time.sleep(0.2)

        append_rows(rows)
        duration_s = time.time() - t_scenario_start
        offered_rate_per_min = (n / duration_s) * 60 if duration_s > 0 else 0
        print(f"Appended {len(rows)} rows for scenario={scenario} to {RESULTS_CSV}")
        print(f"  duration_s={duration_s:.1f}  offered_rate_per_min={offered_rate_per_min:.1f}  "
              f"peak_queue_length={_queue_state['peak']}")
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()


if __name__ == "__main__":
    load_dotenv()
    if len(sys.argv) < 2:
        print("usage: python -m scripts.run_load <scenario> [n_requests]")
        sys.exit(1)
    scenario = sys.argv[1]
    n = int(sys.argv[2]) if len(sys.argv) > 2 else 20
    run_scenario(scenario, n)

"""Sweep retrieval settings (chunk size, k, rerank) over a fixed question set,
using the REAL Groq model so answer quality is meaningful. Appends to
results/results.csv and prints a Table 3 summary.

Grading is manual: this script prints each question + answer + citations and
prompts you to grade it (c=correct, w=wrong, r=refused_correctly, x=refused_wrongly)
so a human (not the model under test) makes the call. Answers are saved so you
can re-grade later without re-calling the API.

Usage: python -m scripts.run_retrieval_settings
"""
from __future__ import annotations

import csv
import json
import sys
import time
from pathlib import Path

from dotenv import load_dotenv

from src.model_client import GroqClient
from src.pipeline import RelayPipeline
from src.retrieval import Retriever

ROOT = Path(__file__).resolve().parent.parent
RESULTS_CSV = ROOT / "results" / "results.csv"
QUESTIONS_PATH = ROOT / "questions_retrieval.json"
GRADES_OUT = ROOT / "results" / "retrieval_grades.json"

FIELDNAMES = [
    "request_id", "scenario", "source", "start_time", "first_token_ms", "total_ms",
    "status", "retries", "tokens_in", "tokens_out", "retrieval_setting", "answer_grade",
]

SETTINGS = [
    {"name": "small_k3_norerank", "words_per_chunk": 100, "k": 3, "rerank": False},
    {"name": "medium_k5_norerank", "words_per_chunk": 200, "k": 5, "rerank": False},
    {"name": "medium_k5_rerank", "words_per_chunk": 200, "k": 5, "rerank": True},
]


def append_rows(rows: list[dict]):
    exists = RESULTS_CSV.exists()
    with RESULTS_CSV.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        if not exists:
            writer.writeheader()
        writer.writerows(rows)


def main():
    load_dotenv()
    questions = json.loads(QUESTIONS_PATH.read_text(encoding="utf-8"))
    client = GroqClient()

    all_grades = []
    for setting in SETTINGS:
        print(f"\n=== setting: {setting['name']} ===")
        retriever = Retriever(words_per_chunk=setting["words_per_chunk"], rerank=setting["rerank"])
        pipeline = RelayPipeline(client=client, retriever=retriever, retrieval_setting=setting["name"])

        rows = []
        for item in questions:
            q = item["q"]
            result = pipeline.answer(q)
            print(f"\nQ: {q}")
            print(f"A: {result.answer}")
            print(f"citations: {result.citations} | status={result.status} | "
                  f"first_token_ms={result.first_token_ms} | total_ms={result.total_ms:.0f} | "
                  f"tokens_out={result.tokens_out}")
            grade = input("Grade [c=correct, w=wrong, r=refused_correctly, x=refused_wrongly]: ").strip().lower()
            grade_map = {"c": "correct", "w": "wrong", "r": "refused_correctly", "x": "refused_wrongly"}
            answer_grade = grade_map.get(grade, "not_graded")

            rows.append({
                "request_id": result.request_id, "scenario": "retrieval_sweep", "source": "real",
                "start_time": time.time(), "first_token_ms": result.first_token_ms,
                "total_ms": result.total_ms, "status": result.status, "retries": result.retries,
                "tokens_in": result.tokens_in, "tokens_out": result.tokens_out,
                "retrieval_setting": setting["name"], "answer_grade": answer_grade,
            })
            all_grades.append({"setting": setting["name"], "question": q, "answer": result.answer,
                                "citations": result.citations, "grade": answer_grade})
            time.sleep(1.0)  # be gentle on the real free-tier RPM limit

        append_rows(rows)

    GRADES_OUT.write_text(json.dumps(all_grades, indent=2), encoding="utf-8")
    print(f"\nWrote grades to {GRADES_OUT} and rows to {RESULTS_CSV}")


if __name__ == "__main__":
    main()

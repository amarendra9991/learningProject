"""Pick one deliberately slow request against the stand-in (configured with a
high slow_success_prob so we reliably hit the slow path) and break its
latency into: waiting (time to first token), working (token generation after
first token), and retrying (the citation-verify branch's second model call,
if triggered). Prints which came before/after the first token and shows the
arithmetic, for heading 4.

Usage: python -m scripts.time_breakdown
"""
from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path

import httpx
from dotenv import load_dotenv

from src.model_client import StandInClient
from src.pipeline import RelayPipeline
from src.retrieval import Retriever

ROOT = Path(__file__).resolve().parent.parent
STANDIN_PORT = 8809
STANDIN_URL = f"http://127.0.0.1:{STANDIN_PORT}"


def start_standin_slow() -> subprocess.Popen:
    env = os.environ.copy()
    env["STANDIN_SLOW_SUCCESS_PROB"] = "1.0"   # force the slow path every time
    env["STANDIN_SLOW_SUCCESS_MULT"] = "6.0"
    env["PORT_OVERRIDE"] = str(STANDIN_PORT)
    proc = subprocess.Popen(
        [sys.executable, "-c",
         f"import uvicorn, src.standin_server as m; uvicorn.run(m.app, host='127.0.0.1', port={STANDIN_PORT}, log_level='warning')"],
        cwd=str(ROOT), env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    for _ in range(50):
        try:
            r = httpx.get(f"{STANDIN_URL}/health", timeout=1.0)
            if r.status_code == 200:
                return proc
        except httpx.HTTPError:
            pass
        time.sleep(0.2)
    raise RuntimeError("stand-in did not start")


def main():
    load_dotenv()
    proc = start_standin_slow()
    try:
        retriever = Retriever(words_per_chunk=200, rerank=False)
        client = StandInClient(base_url=STANDIN_URL)
        pipeline = RelayPipeline(client=client, retriever=retriever)

        result = pipeline.answer("What is multi-head attention and how is it computed?")

        print(f"request_id={result.request_id}  status={result.status}")
        print(f"number of model calls made: {len(result.stream_results)}  (1 = draft only, 2 = draft + citation-verify revise)")

        cumulative = 0.0
        for i, sr in enumerate(result.stream_results):
            label = "draft (initial)" if i == 0 else "retry (citation-verify revise)"
            waiting_ms = sr.first_token_ms if sr.first_token_ms is not None else sr.total_ms
            working_ms = (sr.total_ms - sr.first_token_ms) if sr.first_token_ms is not None else 0.0
            print(f"\ncall[{i}] = {label}")
            print(f"  waiting  (time to first token, delay BEFORE first token) : {waiting_ms:.0f} ms")
            print(f"  working  (generation time AFTER first token)            : {working_ms:.0f} ms")
            print(f"  call total                                              : {sr.total_ms:.0f} ms")
            cumulative += sr.total_ms

        print(f"\nretrying = sum of all calls after the first                 : "
              f"{sum(sr.total_ms for sr in result.stream_results[1:]):.0f} ms")
        print(f"pipeline total_ms (sum of all calls)                         : {result.total_ms:.0f} ms")
        print(f"check: cumulative call totals == pipeline.total_ms -> {abs(cumulative - result.total_ms) < 1.0}")

        if result.stream_results and result.stream_results[0].first_token_ms is not None:
            print(f"\nConclusion: the dominant delay on this request came "
                  f"{'BEFORE' if result.stream_results[0].first_token_ms > (result.stream_results[0].total_ms - result.stream_results[0].first_token_ms) else 'AFTER'} "
                  f"the first token (waiting={result.stream_results[0].first_token_ms:.0f}ms vs "
                  f"working={(result.stream_results[0].total_ms - result.stream_results[0].first_token_ms):.0f}ms on the initial draft call).")
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()


if __name__ == "__main__":
    main()

"""Generate chart PNGs for the PPT from results/results.csv, using the
validated dataviz palette (categorical slot 1 = blue, status colors for
outcomes).
"""
from __future__ import annotations

import csv
from collections import defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

ROOT = Path(__file__).resolve().parent.parent
RESULTS_CSV = ROOT / "results" / "results.csv"
OUT_DIR = ROOT / "ppt_assets"
OUT_DIR.mkdir(exist_ok=True)

SURFACE = "#fcfcfb"
PRIMARY_INK = "#0b0b0b"
SECONDARY_INK = "#52514e"
MUTED = "#898781"
GRIDLINE = "#e1e0d9"
BASELINE = "#c3c2b7"

SERIES_1_BLUE = "#2a78d6"
SERIES_2_ORANGE = "#eb6834"
SERIES_3_AQUA = "#1baf7a"

STATUS_GOOD = "#0ca30c"
STATUS_CRITICAL = "#d03b3b"
STATUS_WARNING = "#fab219"

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Segoe UI", "DejaVu Sans", "Arial"]
plt.rcParams["axes.edgecolor"] = BASELINE
plt.rcParams["text.color"] = PRIMARY_INK
plt.rcParams["axes.labelcolor"] = SECONDARY_INK
plt.rcParams["xtick.color"] = MUTED
plt.rcParams["ytick.color"] = MUTED


def pctile(values, p):
    if not values:
        return 0
    s = sorted(values)
    k = (len(s) - 1) * (p / 100)
    f = int(k)
    c = min(f + 1, len(s) - 1)
    if f == c:
        return s[f]
    return s[f] + (s[c] - s[f]) * (k - f)


def load_rows():
    return list(csv.DictReader(RESULTS_CSV.open(encoding="utf-8")))


def chart_latency():
    rows = load_rows()
    by_scenario = defaultdict(list)
    for r in rows:
        if r["scenario"] in ("steady", "burst", "sustained_overload", "per_minute_halved", "daily_exhausted"):
            by_scenario[r["scenario"]].append(r)

    order = ["steady", "burst", "sustained_overload", "per_minute_halved", "daily_exhausted"]
    labels = ["Steady", "Burst", "Sustained\noverload", "Per-min limit\nhalved", "Daily budget\nexhausted"]

    p50s, p95s = [], []
    for s in order:
        tot = [float(r["total_ms"]) for r in by_scenario[s] if r["total_ms"] not in ("", None)]
        p50s.append(pctile(tot, 50))
        p95s.append(pctile(tot, 95))

    fig, ax = plt.subplots(figsize=(9, 4.8), dpi=200)
    fig.patch.set_facecolor(SURFACE)
    ax.set_facecolor(SURFACE)

    x = range(len(order))
    width = 0.32
    bars1 = ax.bar([i - width/2 for i in x], p50s, width, label="Total time p50 (ms)", color=SERIES_1_BLUE, zorder=3)
    bars2 = ax.bar([i + width/2 for i in x], p95s, width, label="Total time p95 (ms)", color=SERIES_2_ORANGE, zorder=3)

    for b in list(bars1) + list(bars2):
        h = b.get_height()
        if h > 0:
            ax.annotate(f"{h:,.0f}", (b.get_x() + b.get_width()/2, h), textcoords="offset points",
                        xytext=(0, 4), ha="center", fontsize=9, color=SECONDARY_INK)

    ax.set_xticks(list(x))
    ax.set_xticklabels(labels, fontsize=10)
    ax.set_ylabel("Total response time (ms)", fontsize=10)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(BASELINE)
    ax.spines["bottom"].set_color(BASELINE)
    ax.yaxis.grid(True, color=GRIDLINE, linewidth=0.8, zorder=0)
    ax.set_axisbelow(True)
    ax.legend(frameon=False, loc="upper left", fontsize=9)
    ax.set_title("Total time by load scenario (stand-in)", fontsize=12, color=PRIMARY_INK, loc="left", pad=12)

    fig.tight_layout()
    fig.savefig(OUT_DIR / "chart_latency.png", facecolor=SURFACE)
    plt.close(fig)


def chart_outcomes():
    rows = load_rows()
    by_scenario = defaultdict(list)
    for r in rows:
        if r["scenario"] in ("steady", "burst", "sustained_overload", "per_minute_halved", "daily_exhausted"):
            by_scenario[r["scenario"]].append(r)

    order = ["steady", "burst", "sustained_overload", "per_minute_halved", "daily_exhausted"]
    labels = ["Steady", "Burst", "Sustained\noverload", "Per-min limit\nhalved", "Daily budget\nexhausted"]

    succeeded, rate_limited = [], []
    for s in order:
        rs = by_scenario[s]
        n = len(rs)
        statuses = [r["status"] for r in rs]
        succeeded.append(100 * statuses.count("ok") / n if n else 0)
        rate_limited.append(100 * (statuses.count("rate_limited") + statuses.count("refused_budget")) / n if n else 0)

    fig, ax = plt.subplots(figsize=(9, 4.8), dpi=200)
    fig.patch.set_facecolor(SURFACE)
    ax.set_facecolor(SURFACE)

    x = range(len(order))
    bars_ok = ax.bar(x, succeeded, 0.5, label="Succeeded %", color=STATUS_GOOD, zorder=3)
    bars_rl = ax.bar(x, rate_limited, 0.5, bottom=succeeded, label="Rate-limited / refused %", color=STATUS_CRITICAL, zorder=3)

    for i, (ok, rl) in enumerate(zip(succeeded, rate_limited)):
        if ok > 0:
            ax.annotate(f"{ok:.0f}%", (i, ok/2), ha="center", va="center", fontsize=9, color="white")
        if rl > 0:
            ax.annotate(f"{rl:.0f}%", (i, ok + rl/2), ha="center", va="center", fontsize=9, color="white")

    ax.set_xticks(list(x))
    ax.set_xticklabels(labels, fontsize=10)
    ax.set_ylabel("% of requests", fontsize=10)
    ax.set_ylim(0, 105)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(BASELINE)
    ax.spines["bottom"].set_color(BASELINE)
    ax.yaxis.grid(True, color=GRIDLINE, linewidth=0.8, zorder=0)
    ax.set_axisbelow(True)
    ax.legend(frameon=False, loc="upper center", bbox_to_anchor=(0.5, -0.15), ncol=2, fontsize=9)
    ax.set_title("Outcomes by load scenario (stand-in)", fontsize=12, color=PRIMARY_INK, loc="left", pad=12)

    fig.tight_layout()
    fig.savefig(OUT_DIR / "chart_outcomes.png", facecolor=SURFACE)
    plt.close(fig)


def chart_time_breakdown():
    labels = ["Draft (initial)", "Retry\n(citation-verify)"]
    waiting = [1416, 731]
    working = [6421, 4037]

    fig, ax = plt.subplots(figsize=(7.5, 4.2), dpi=200)
    fig.patch.set_facecolor(SURFACE)
    ax.set_facecolor(SURFACE)

    x = range(len(labels))
    bars_wait = ax.barh(x, waiting, color=SERIES_3_AQUA, label="Waiting (before 1st token)", zorder=3)
    bars_work = ax.barh(x, working, left=waiting, color=SERIES_1_BLUE, label="Working (after 1st token)", zorder=3)

    for i, (w, k) in enumerate(zip(waiting, working)):
        ax.annotate(f"{w:,} ms", (w/2, i), ha="center", va="center", fontsize=9, color="white")
        ax.annotate(f"{k:,} ms", (w + k/2, i), ha="center", va="center", fontsize=9, color="white")
        ax.annotate(f"total {w+k:,} ms", (w + k + 150, i), ha="left", va="center", fontsize=9, color=SECONDARY_INK)

    ax.set_yticks(list(x))
    ax.set_yticklabels(labels, fontsize=10)
    ax.set_xlabel("Milliseconds", fontsize=10)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(BASELINE)
    ax.spines["bottom"].set_color(BASELINE)
    ax.xaxis.grid(True, color=GRIDLINE, linewidth=0.8, zorder=0)
    ax.set_axisbelow(True)
    ax.legend(frameon=False, loc="lower right", fontsize=9)
    ax.set_title("Where the time goes — one slow request", fontsize=12, color=PRIMARY_INK, loc="left", pad=12)
    ax.invert_yaxis()

    fig.tight_layout()
    fig.savefig(OUT_DIR / "chart_time_breakdown.png", facecolor=SURFACE)
    plt.close(fig)


if __name__ == "__main__":
    chart_latency()
    chart_outcomes()
    chart_time_breakdown()
    print(f"Charts written to {OUT_DIR}")

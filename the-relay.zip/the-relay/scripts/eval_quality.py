"""Run the 15 handwritten quality questions against real Groq with the chosen
retrieval setting, record tokens used and a human-assigned grade. Appends to
results/results.csv.

Usage: python -m scripts.eval_quality
"""
from __future__ import annotations

import csv
import json
import time
from pathlib import Path

from dotenv import load_dotenv

from src.model_client import GroqClient
from src.pipeline import RelayPipeline
from src.retrieval import Retriever

ROOT = Path(__file__).resolve().parent.parent
RESULTS_CSV = ROOT / "results" / "results.csv"
QUESTIONS_PATH = ROOT / "questions_quality.json"
GRADES_OUT = ROOT / "results" / "quality_grades.json"

FIELDNAMES = [
    "request_id", "scenario", "source", "start_time", "first_token_ms", "total_ms",
    "status", "retries", "tokens_in", "tokens_out", "retrieval_setting", "answer_grade",
]

CHOSEN_SETTING_NAME = "medium_k5_norerank"
CHOSEN_WORDS_PER_CHUNK = 200
CHOSEN_K = 5
CHOSEN_RERANK = False


def append_rows(rows: list[dict]):
    exists = RESULTS_CSV.exists()
    with RESULTS_CSV.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        if not exists:
            writer.writeheader()
        writer.writerows(rows)


def main():
    load_dotenv()
    questions = json.loads(QUESTIONS_PATH.read_text(encoding="utf-8"))
    client = GroqClient()
    retriever = Retriever(words_per_chunk=CHOSEN_WORDS_PER_CHUNK, rerank=CHOSEN_RERANK)
    pipeline = RelayPipeline(client=client, retriever=retriever, retrieval_setting=CHOSEN_SETTING_NAME)

    rows = []
    grades = []
    for item in questions:
        q = item["q"]
        result = pipeline.answer(q)
        print(f"\nQ: {q}  (expect: {item['expect']})")
        print(f"A: {result.answer}")
        print(f"citations: {result.citations} | tokens_out={result.tokens_out} | total_ms={result.total_ms:.0f}")
        grade = input("Grade [c=correct, w=wrong, r=refused_correctly, x=refused_wrongly]: ").strip().lower()
        grade_map = {"c": "correct", "w": "wrong", "r": "refused_correctly", "x": "refused_wrongly"}
        answer_grade = grade_map.get(grade, "not_graded")

        rows.append({
            "request_id": result.request_id, "scenario": "quality_eval", "source": "real",
            "start_time": time.time(), "first_token_ms": result.first_token_ms,
            "total_ms": result.total_ms, "status": result.status, "retries": result.retries,
            "tokens_in": result.tokens_in, "tokens_out": result.tokens_out,
            "retrieval_setting": CHOSEN_SETTING_NAME, "answer_grade": answer_grade,
        })
        grades.append({"question": q, "expect": item["expect"], "answer": result.answer,
                        "citations": result.citations, "grade": answer_grade,
                        "tokens_out": result.tokens_out})
        time.sleep(1.0)

    append_rows(rows)
    GRADES_OUT.write_text(json.dumps(grades, indent=2), encoding="utf-8")
    print(f"\nWrote grades to {GRADES_OUT} and rows to {RESULTS_CSV}")


if __name__ == "__main__":
    main()

"""Download the pinned arXiv papers, extract text per page, and chunk into passages.

Run as a script: python -m src.ingest
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, asdict
from pathlib import Path

import httpx
import pdfplumber

PAPERS_DIR = Path(__file__).resolve().parent.parent / "papers"

PAPERS = [
    {
        "id": "attention",
        "title": "Attention Is All You Need",
        "arxiv_id": "1706.03762",
        "version": "v7",
        "url": "https://arxiv.org/pdf/1706.03762v7",
    },
    {
        "id": "moshi",
        "title": "Moshi: a speech-text foundation model for real-time dialogue",
        "arxiv_id": "2410.00037",
        "version": "v1",
        "url": "https://arxiv.org/pdf/2410.00037v1",
    },
    {
        "id": "dynamic_chunking",
        "title": "Dynamic Chunking for End-to-End Hierarchical Sequence Modeling",
        "arxiv_id": "2507.07955",
        "version": "v2",
        "url": "https://arxiv.org/pdf/2507.07955v2",
    },
]


@dataclass
class Chunk:
    chunk_id: str
    paper_id: str
    paper_title: str
    page: int
    text: str


def download_papers() -> None:
    PAPERS_DIR.mkdir(parents=True, exist_ok=True)
    with httpx.Client(follow_redirects=True, timeout=60.0) as client:
        for p in PAPERS:
            dest = PAPERS_DIR / f"{p['id']}_{p['arxiv_id']}{p['version']}.pdf"
            if dest.exists():
                print(f"[skip] {dest.name} already present")
                continue
            print(f"[fetch] {p['url']} -> {dest.name}")
            resp = client.get(p["url"])
            resp.raise_for_status()
            dest.write_bytes(resp.content)


def extract_pages(pdf_path: Path) -> list[tuple[int, str]]:
    pages: list[tuple[int, str]] = []
    with pdfplumber.open(pdf_path) as pdf:
        for i, page in enumerate(pdf.pages, start=1):
            text = page.extract_text() or ""
            pages.append((i, text))
    return pages


def _normalize(text: str) -> str:
    text = text.replace("\n", " ")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def chunk_pages(paper_id: str, paper_title: str, pages: list[tuple[int, str]], words_per_chunk: int = 200) -> list[Chunk]:
    """Split each page's text into fixed-size word windows (no overlap).

    Chunk size is a parameter so run_retrieval_settings.py can vary it for Table 3.
    """
    chunks: list[Chunk] = []
    for page_num, raw_text in pages:
        text = _normalize(raw_text)
        if not text:
            continue
        words = text.split(" ")
        for start in range(0, len(words), words_per_chunk):
            piece = " ".join(words[start:start + words_per_chunk]).strip()
            if not piece:
                continue
            chunk_id = f"{paper_id}_p{page_num}_w{start}"
            chunks.append(Chunk(chunk_id=chunk_id, paper_id=paper_id, paper_title=paper_title, page=page_num, text=piece))
    return chunks


def build_index(words_per_chunk: int = 200, cache_name: str | None = None) -> list[Chunk]:
    """Build (or load cached) chunk list across all three papers for a given chunk size."""
    cache_name = cache_name or f"chunks_{words_per_chunk}.json"
    cache_path = PAPERS_DIR / cache_name
    if cache_path.exists():
        data = json.loads(cache_path.read_text(encoding="utf-8"))
        return [Chunk(**c) for c in data]

    download_papers()
    all_chunks: list[Chunk] = []
    for p in PAPERS:
        pdf_path = PAPERS_DIR / f"{p['id']}_{p['arxiv_id']}{p['version']}.pdf"
        pages = extract_pages(pdf_path)
        chunks = chunk_pages(p["id"], p["title"], pages, words_per_chunk=words_per_chunk)
        all_chunks.extend(chunks)
        print(f"[chunked] {p['id']}: {len(pages)} pages -> {len(chunks)} chunks")

    cache_path.write_text(json.dumps([asdict(c) for c in all_chunks], indent=0), encoding="utf-8")
    return all_chunks


if __name__ == "__main__":
    chunks = build_index(words_per_chunk=200)
    print(f"Total chunks: {len(chunks)}")

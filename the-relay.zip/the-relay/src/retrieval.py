"""BM25 lexical retrieval over the chunked paper index.

Parameters (chunk size via src.ingest.build_index, k, rerank) are exposed so
scripts/run_retrieval_settings.py can sweep them for Table 3.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from rank_bm25 import BM25Okapi

from src.ingest import Chunk, build_index

_TOKEN_RE = re.compile(r"[a-z0-9]+")


def tokenize(text: str) -> list[str]:
    return _TOKEN_RE.findall(text.lower())


@dataclass
class RetrievedChunk:
    chunk: Chunk
    score: float


class Retriever:
    def __init__(self, words_per_chunk: int = 200, rerank: bool = False):
        self.words_per_chunk = words_per_chunk
        self.rerank = rerank
        self.chunks: list[Chunk] = build_index(words_per_chunk=words_per_chunk)
        self._corpus_tokens = [tokenize(c.text) for c in self.chunks]
        self.bm25 = BM25Okapi(self._corpus_tokens)

    def search(self, query: str, k: int = 5) -> list[RetrievedChunk]:
        q_tokens = tokenize(query)
        scores = self.bm25.get_scores(q_tokens)
        ranked = sorted(zip(self.chunks, scores), key=lambda x: x[1], reverse=True)
        top = ranked[: max(k * 3, k) if self.rerank else k]
        results = [RetrievedChunk(chunk=c, score=float(s)) for c, s in top]
        if self.rerank:
            results = self._lexical_rerank(query, results)[:k]
        return results

    def _lexical_rerank(self, query: str, candidates: list[RetrievedChunk]) -> list[RetrievedChunk]:
        """Cheap re-rank: boost chunks whose token-overlap ratio with the query is highest.

        No embedding model available on Groq's free tier, so re-ranking stays lexical
        (exact/substring term coverage) rather than semantic.
        """
        q_tokens = set(tokenize(query))
        if not q_tokens:
            return candidates

        def overlap_ratio(rc: RetrievedChunk) -> float:
            c_tokens = set(tokenize(rc.chunk.text))
            return len(q_tokens & c_tokens) / len(q_tokens)

        rescored = [
            RetrievedChunk(chunk=rc.chunk, score=rc.score * 0.7 + overlap_ratio(rc) * 10.0)
            for rc in candidates
        ]
        return sorted(rescored, key=lambda x: x.score, reverse=True)

    def best_score(self, query: str) -> float:
        q_tokens = tokenize(query)
        scores = self.bm25.get_scores(q_tokens)
        return float(max(scores)) if len(scores) else 0.0


if __name__ == "__main__":
    r = Retriever(words_per_chunk=200, rerank=False)
    hits = r.search("multi-head attention scaled dot product", k=5)
    for h in hits:
        print(f"{h.score:6.2f}  {h.chunk.paper_id} p{h.chunk.page}  {h.chunk.text[:80]!r}")

"""Local per-minute / per-day request and token budget tracker.

Sits in front of the pipeline's model calls. This is what makes heading 5
("when a limit is hit") and heading 7 ("3pm the daily budget is gone")
testable on demand, without needing to actually exhaust the live Groq
account's real daily cap.
"""
from __future__ import annotations

import time
from dataclasses import dataclass


class BudgetExhausted(Exception):
    """Raised when the daily budget is gone: no delay will help, caller must be refused."""
    def __init__(self, reset_in_s: float):
        self.reset_in_s = reset_in_s
        super().__init__(f"daily budget exhausted, resets in {reset_in_s:.0f}s")


@dataclass
class BudgetTracker:
    rpm_limit: int = 30
    rpd_limit: int = 500
    tpm_limit: int = 20000

    def __post_init__(self):
        self._minute_bucket = int(time.time() // 60)
        self._requests_this_minute = 0
        self._tokens_this_minute = 0
        self._day_bucket = int(time.time() // 86400)
        self._requests_today = 0

    def _roll_buckets(self):
        now = time.time()
        mb = int(now // 60)
        if mb != self._minute_bucket:
            self._minute_bucket = mb
            self._requests_this_minute = 0
            self._tokens_this_minute = 0
        db = int(now // 86400)
        if db != self._day_bucket:
            self._day_bucket = db
            self._requests_today = 0

    def seconds_to_next_minute(self) -> float:
        return (self._minute_bucket + 1) * 60 - time.time()

    def seconds_to_next_day(self) -> float:
        return (self._day_bucket + 1) * 86400 - time.time()

    def check_and_reserve(self, est_tokens: int) -> tuple[bool, float]:
        """Returns (allowed, wait_seconds). If daily budget is gone, raises BudgetExhausted
        (no amount of waiting helps within a reasonable horizon, unlike the per-minute cap).
        """
        self._roll_buckets()

        if self._requests_today >= self.rpd_limit:
            raise BudgetExhausted(self.seconds_to_next_day())

        if (self._requests_this_minute >= self.rpm_limit) or (
            self._tokens_this_minute + est_tokens > self.tpm_limit
        ):
            return False, self.seconds_to_next_minute()

        self._requests_this_minute += 1
        self._tokens_this_minute += est_tokens
        self._requests_today += 1
        return True, 0.0

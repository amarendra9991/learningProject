"""Ask a single question end-to-end. Defaults to the stand-in; pass --real for Groq.

Usage:
  python -m src.cli "What is the dropout rate used in the base Transformer model?"
  python -m src.cli --real "..."
"""
from __future__ import annotations

import sys

from dotenv import load_dotenv

from src.model_client import GroqClient, StandInClient
from src.retrieval import Retriever


def main():
    load_dotenv()
    args = sys.argv[1:]
    use_real = "--real" in args
    args = [a for a in args if a != "--real"]
    if not args:
        print("usage: python -m src.cli [--real] \"question\"")
        sys.exit(1)
    question = args[0]

    from src.pipeline import RelayPipeline

    client = GroqClient() if use_real else StandInClient()
    retriever = Retriever(words_per_chunk=200, rerank=False)
    pipeline = RelayPipeline(client=client, retriever=retriever, retrieval_setting="default")

    result = pipeline.answer(question)
    print(f"--- status: {result.status} | first_token_ms={result.first_token_ms} | "
          f"total_ms={result.total_ms:.0f} | retries={result.retries} | "
          f"tokens_in={result.tokens_in} tokens_out={result.tokens_out} ---")
    print(result.answer)
    print(f"citations: {result.citations}")


if __name__ == "__main__":
    main()

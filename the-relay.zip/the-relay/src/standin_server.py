"""Local stand-in model service.

Mimics a hosted LLM API closely enough to load-test the pipeline when the
real Groq free tier can't take the traffic: it can be slow, fail, refuse at a
rate limit, slow down further under concurrent load, and streams its reply a
token at a time.

Calibration (see WRITEUP.md heading 2): base per-token delay and the
failure/slow-success probabilities are set from what scripts/probe_groq.py
measured on the real service. Where it differs most from the real thing: the
real service's latency comes from a shared multi-tenant queue with its own
jitter and provider-side retries; this stand-in only draws i.i.d. samples
from a lognormal plus a simple queue-depth multiplier, so it won't reproduce
correlated slowdowns across many different callers' requests.
"""
from __future__ import annotations

import asyncio
import json
import os
import random
import time
from dataclasses import dataclass, field

from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse, JSONResponse

app = FastAPI()


@dataclass
class StandInConfig:
    # latency model: lognormal(mu, sigma) seconds for per-token delay, calibrated from Groq probe
    base_token_delay_mu: float = -4.0   # ~exp(-4) ~= 0.018s per token baseline
    base_token_delay_sigma: float = 0.5
    startup_delay_mu: float = -1.5      # time-to-first-token baseline, seconds (log-space)
    startup_delay_sigma: float = 0.6
    # failure modes
    hard_fail_prob: float = 0.02
    slow_success_prob: float = 0.03     # succeeds but takes far longer than usual
    slow_success_multiplier: float = 8.0
    # rate limits enforced by this stand-in itself
    rpm_limit: int = 30
    rpd_limit: int = 1000
    # load-dependent slowdown: delay multiplier grows with number of in-flight requests
    load_slowdown_per_inflight: float = 0.15  # +15% latency per concurrent in-flight request


def _config_from_env() -> StandInConfig:
    """Env vars let scripts/run_load.py launch the stand-in with scenario-specific
    limits (e.g. STANDIN_RPM_LIMIT=15 for the per_minute_halved scenario) without
    editing this file.
    """
    defaults = StandInConfig()
    return StandInConfig(
        base_token_delay_mu=float(os.environ.get("STANDIN_TOKEN_DELAY_MU", defaults.base_token_delay_mu)),
        base_token_delay_sigma=float(os.environ.get("STANDIN_TOKEN_DELAY_SIGMA", defaults.base_token_delay_sigma)),
        startup_delay_mu=float(os.environ.get("STANDIN_STARTUP_DELAY_MU", defaults.startup_delay_mu)),
        startup_delay_sigma=float(os.environ.get("STANDIN_STARTUP_DELAY_SIGMA", defaults.startup_delay_sigma)),
        hard_fail_prob=float(os.environ.get("STANDIN_HARD_FAIL_PROB", defaults.hard_fail_prob)),
        slow_success_prob=float(os.environ.get("STANDIN_SLOW_SUCCESS_PROB", defaults.slow_success_prob)),
        slow_success_multiplier=float(os.environ.get("STANDIN_SLOW_SUCCESS_MULT", defaults.slow_success_multiplier)),
        rpm_limit=int(os.environ.get("STANDIN_RPM_LIMIT", defaults.rpm_limit)),
        rpd_limit=int(os.environ.get("STANDIN_RPD_LIMIT", defaults.rpd_limit)),
        load_slowdown_per_inflight=float(os.environ.get("STANDIN_LOAD_SLOWDOWN", defaults.load_slowdown_per_inflight)),
    )


config = _config_from_env()

_state = {
    "inflight": 0,
    "minute_bucket": int(time.time() // 60),
    "requests_this_minute": 0,
    "day_bucket": int(time.time() // 86400),
    "requests_today": 0,
    "lock": asyncio.Lock(),
}


def _rate_limit_check() -> tuple[bool, float]:
    """Returns (is_limited, retry_after_seconds)."""
    now = time.time()
    minute_bucket = int(now // 60)
    day_bucket = int(now // 86400)

    if minute_bucket != _state["minute_bucket"]:
        _state["minute_bucket"] = minute_bucket
        _state["requests_this_minute"] = 0
    if day_bucket != _state["day_bucket"]:
        _state["day_bucket"] = day_bucket
        _state["requests_today"] = 0

    if _state["requests_today"] >= config.rpd_limit:
        seconds_left = (day_bucket + 1) * 86400 - now
        return True, seconds_left
    if _state["requests_this_minute"] >= config.rpm_limit:
        seconds_left = (minute_bucket + 1) * 60 - now
        return True, seconds_left

    _state["requests_this_minute"] += 1
    _state["requests_today"] += 1
    return False, 0.0


SAMPLE_ANSWER_TOKENS = (
    "Based on the retrieved passages , the answer involves several steps "
    "that are described in the cited section of the paper . The mechanism "
    "combines the relevant components as outlined , with citations pointing "
    "to the exact page where this is discussed in detail ."
).split(" ")


async def _token_stream(n_tokens: int, inflight_at_start: int):
    load_mult = 1.0 + config.load_slowdown_per_inflight * inflight_at_start

    is_slow = random.random() < config.slow_success_prob
    slow_mult = config.slow_success_multiplier if is_slow else 1.0

    startup_delay = random.lognormvariate(config.startup_delay_mu, config.startup_delay_sigma) * load_mult * slow_mult
    await asyncio.sleep(startup_delay)

    for i in range(n_tokens):
        token = SAMPLE_ANSWER_TOKENS[i % len(SAMPLE_ANSWER_TOKENS)] + " "
        chunk = json.dumps({"delta": token})
        yield f"data: {chunk}\n\n"
        per_token_delay = random.lognormvariate(
            config.base_token_delay_mu, config.base_token_delay_sigma
        ) * load_mult * slow_mult
        await asyncio.sleep(per_token_delay)

    yield "data: [DONE]\n\n"


@app.post("/v1/chat/completions")
async def chat_completions(request: Request):
    body = await request.json()
    max_tokens = int(body.get("max_tokens", 100))
    n_tokens = min(max_tokens, random.randint(30, 80))

    limited, retry_after = _rate_limit_check()
    if limited:
        return JSONResponse(
            status_code=429,
            content={"error": "rate_limited"},
            headers={"retry-after": str(round(retry_after, 2))},
        )

    if random.random() < config.hard_fail_prob:
        return JSONResponse(status_code=500, content={"error": "internal_error"})

    _state["inflight"] += 1
    inflight_at_start = _state["inflight"]
    try:
        async def gen():
            async for piece in _token_stream(n_tokens, inflight_at_start):
                yield piece
            _state["inflight"] -= 1

        return StreamingResponse(gen(), media_type="text/event-stream")
    except Exception:
        _state["inflight"] -= 1
        raise


@app.get("/health")
async def health():
    return {"status": "ok", "inflight": _state["inflight"]}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8808, log_level="warning")

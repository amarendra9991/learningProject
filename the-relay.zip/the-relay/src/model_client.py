"""Model client abstraction: a real Groq client and a local stand-in client,
both speaking the same minimal streaming chat interface so the pipeline code
is identical regardless of source.
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field

import httpx

GROQ_BASE_URL = "https://api.groq.com/openai/v1"
GROQ_MODEL = "llama-3.1-8b-instant"


@dataclass
class StreamResult:
    text: str
    first_token_ms: float | None
    total_ms: float
    status: str  # ok, rate_limited, timeout, error
    retries: int
    tokens_in: int
    tokens_out: int
    rate_limit_headers: dict = field(default_factory=dict)
    retry_after_s: float | None = None


class RateLimitError(Exception):
    def __init__(self, retry_after: float | None, headers: dict):
        self.retry_after = retry_after
        self.headers = headers
        super().__init__(f"rate limited, retry_after={retry_after}")


def _extract_rate_headers(resp: httpx.Response) -> dict:
    keys = [
        "x-ratelimit-limit-requests",
        "x-ratelimit-limit-tokens",
        "x-ratelimit-remaining-requests",
        "x-ratelimit-remaining-tokens",
        "x-ratelimit-reset-requests",
        "x-ratelimit-reset-tokens",
        "retry-after",
    ]
    return {k: resp.headers.get(k) for k in keys if resp.headers.get(k) is not None}


class GroqClient:
    """Thin streaming client for Groq's OpenAI-compatible chat completions endpoint."""

    def __init__(self, api_key: str | None = None, model: str = GROQ_MODEL, timeout: float = 30.0):
        self.api_key = api_key or os.environ.get("GROQ_API_KEY")
        if not self.api_key:
            raise RuntimeError("GROQ_API_KEY not set in environment")
        self.model = model
        self.timeout = timeout

    def chat_stream(self, messages: list[dict], max_tokens: int = 512, temperature: float = 0.0) -> StreamResult:
        url = f"{GROQ_BASE_URL}/chat/completions"
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        payload = {
            "model": self.model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": True,
        }

        t_start = time.monotonic()
        first_token_t: float | None = None
        text_parts: list[str] = []
        tokens_out_estimate = 0

        try:
            with httpx.Client(timeout=self.timeout) as client:
                with client.stream("POST", url, headers=headers, json=payload) as resp:
                    if resp.status_code == 429:
                        resp.read()
                        rl_headers = _extract_rate_headers(resp)
                        retry_after = float(rl_headers.get("retry-after", 0)) if rl_headers.get("retry-after") else None
                        return StreamResult(
                            text="", first_token_ms=None, total_ms=(time.monotonic() - t_start) * 1000,
                            status="rate_limited", retries=0, tokens_in=0, tokens_out=0,
                            rate_limit_headers=rl_headers, retry_after_s=retry_after,
                        )
                    resp.raise_for_status()
                    rl_headers = _extract_rate_headers(resp)
                    for line in resp.iter_lines():
                        if not line or not line.startswith("data: "):
                            continue
                        data = line[len("data: "):]
                        if data.strip() == "[DONE]":
                            break
                        try:
                            obj = json.loads(data)
                        except json.JSONDecodeError:
                            continue
                        delta = obj.get("choices", [{}])[0].get("delta", {})
                        piece = delta.get("content")
                        if piece:
                            if first_token_t is None:
                                first_token_t = time.monotonic()
                            text_parts.append(piece)
                            tokens_out_estimate += max(1, len(piece.split()))
        except httpx.TimeoutException:
            return StreamResult(
                text="".join(text_parts), first_token_ms=None,
                total_ms=(time.monotonic() - t_start) * 1000, status="timeout",
                retries=0, tokens_in=0, tokens_out=tokens_out_estimate,
            )
        except httpx.HTTPError as e:
            return StreamResult(
                text="".join(text_parts), first_token_ms=None,
                total_ms=(time.monotonic() - t_start) * 1000, status="error",
                retries=0, tokens_in=0, tokens_out=tokens_out_estimate,
            )

        total_ms = (time.monotonic() - t_start) * 1000
        ft_ms = (first_token_t - t_start) * 1000 if first_token_t else None
        tokens_in_estimate = sum(len(m.get("content", "").split()) for m in messages)
        return StreamResult(
            text="".join(text_parts), first_token_ms=ft_ms, total_ms=total_ms,
            status="ok", retries=0, tokens_in=tokens_in_estimate, tokens_out=tokens_out_estimate,
            rate_limit_headers=rl_headers,
        )


class StandInClient:
    """Client for the local stand-in model service (src/standin_server.py)."""

    def __init__(self, base_url: str = "http://127.0.0.1:8808", timeout: float = 20.0):
        self.base_url = base_url
        self.timeout = timeout

    def chat_stream(self, messages: list[dict], max_tokens: int = 512, temperature: float = 0.0) -> StreamResult:
        url = f"{self.base_url}/v1/chat/completions"
        payload = {"messages": messages, "max_tokens": max_tokens, "temperature": temperature, "stream": True}

        t_start = time.monotonic()
        first_token_t: float | None = None
        text_parts: list[str] = []
        tokens_out_estimate = 0

        try:
            with httpx.Client(timeout=self.timeout) as client:
                with client.stream("POST", url, json=payload) as resp:
                    if resp.status_code == 429:
                        resp.read()
                        retry_after = resp.headers.get("retry-after")
                        return StreamResult(
                            text="", first_token_ms=None, total_ms=(time.monotonic() - t_start) * 1000,
                            status="rate_limited", retries=0, tokens_in=0, tokens_out=0,
                            retry_after_s=float(retry_after) if retry_after else None,
                        )
                    resp.raise_for_status()
                    for line in resp.iter_lines():
                        if not line or not line.startswith("data: "):
                            continue
                        data = line[len("data: "):]
                        if data.strip() == "[DONE]":
                            break
                        try:
                            obj = json.loads(data)
                        except json.JSONDecodeError:
                            continue
                        piece = obj.get("delta", "")
                        if piece:
                            if first_token_t is None:
                                first_token_t = time.monotonic()
                            text_parts.append(piece)
                            tokens_out_estimate += max(1, len(piece.split()))
        except httpx.TimeoutException:
            return StreamResult(
                text="".join(text_parts), first_token_ms=None,
                total_ms=(time.monotonic() - t_start) * 1000, status="timeout",
                retries=0, tokens_in=0, tokens_out=tokens_out_estimate,
            )
        except httpx.HTTPError:
            return StreamResult(
                text="".join(text_parts), first_token_ms=None,
                total_ms=(time.monotonic() - t_start) * 1000, status="error",
                retries=0, tokens_in=0, tokens_out=tokens_out_estimate,
            )

        total_ms = (time.monotonic() - t_start) * 1000
        ft_ms = (first_token_t - t_start) * 1000 if first_token_t else None
        tokens_in_estimate = sum(len(m.get("content", "").split()) for m in messages)
        return StreamResult(
            text="".join(text_parts), first_token_ms=ft_ms, total_ms=total_ms,
            status="ok", retries=0, tokens_in=tokens_in_estimate, tokens_out=tokens_out_estimate,
        )

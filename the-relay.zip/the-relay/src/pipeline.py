"""The Relay pipeline.

Steps:
  1. classify intent + extract search query        (LLM call)
  2. retrieve passages                              (tool call: BM25)
  3. sufficiency loop: broaden + re-retrieve if thin (loop, capped at 2 extra tries)
  4. draft a cited answer, streamed                 (LLM call)
  5. citation-verify branch: revise once or refuse  (branch)
  6. respond, with full timing/outcome record for results.csv
"""
from __future__ import annotations

import re
import time
import uuid
from dataclasses import dataclass, field

from src.budget import BudgetTracker, BudgetExhausted
from src.model_client import GroqClient, StandInClient, StreamResult
from src.retrieval import Retriever, RetrievedChunk

SUFFICIENCY_SCORE_THRESHOLD = 3.0
MAX_RETRIEVE_LOOPS = 2
STOPWORDS = {"the", "a", "an", "is", "are", "of", "in", "on", "to", "what", "how", "does", "do", "paper", "papers"}


@dataclass
class PipelineResult:
    request_id: str
    answer: str
    citations: list[str]
    status: str  # ok, rate_limited, timeout, error, refused_budget
    answer_grade_hint: str  # correct|wrong|refused_correctly|refused_wrongly -- filled by human grading later; here just "answered"/"refused"
    first_token_ms: float | None
    total_ms: float
    retries: int
    tokens_in: int
    tokens_out: int
    retrieval_setting: str
    stream_results: list[StreamResult] = field(default_factory=list)


def _broaden_query(query: str) -> str:
    words = [w for w in re.findall(r"[a-zA-Z0-9]+", query.lower()) if w not in STOPWORDS]
    return " ".join(words) if words else query


def _format_context(chunks: list[RetrievedChunk]) -> str:
    lines = []
    for rc in chunks:
        c = rc.chunk
        lines.append(f"[{c.paper_id} p{c.page}] {c.text}")
    return "\n\n".join(lines)


def _extract_citations(answer_text: str) -> list[str]:
    return re.findall(r"\[([a-z_]+ p\d+)\]", answer_text)


def _citations_valid(citations: list[str], retrieved: list[RetrievedChunk]) -> bool:
    valid_tags = {f"{rc.chunk.paper_id} p{rc.chunk.page}" for rc in retrieved}
    if not citations:
        return False
    return all(c in valid_tags for c in citations)


class RelayPipeline:
    def __init__(self, client, retriever: Retriever, budget: BudgetTracker | None = None,
                 retrieval_setting: str = "default", max_tokens: int = 400):
        self.client = client
        self.retriever = retriever
        self.budget = budget
        self.retrieval_setting = retrieval_setting
        self.max_tokens = max_tokens

    def answer(self, question: str) -> PipelineResult:
        request_id = str(uuid.uuid4())[:8]
        stream_results: list[StreamResult] = []
        retries = 0

        # --- budget gate ---
        if self.budget is not None:
            try:
                allowed, wait_s = self.budget.check_and_reserve(est_tokens=self.max_tokens + 100)
                if not allowed:
                    time.sleep(min(wait_s, 2.0))  # bounded wait for demo purposes; real deployment would queue
                    allowed, wait_s = self.budget.check_and_reserve(est_tokens=self.max_tokens + 100)
                    retries += 1
                    if not allowed:
                        return PipelineResult(
                            request_id=request_id, answer="", citations=[], status="rate_limited",
                            answer_grade_hint="refused", first_token_ms=None, total_ms=0, retries=retries,
                            tokens_in=0, tokens_out=0, retrieval_setting=self.retrieval_setting,
                        )
            except BudgetExhausted:
                return PipelineResult(
                    request_id=request_id,
                    answer=("The daily question budget has been used up for today. "
                            "Please try again after it resets, or ask a shorter, more specific question "
                            "tomorrow — no new answers can be generated until the budget resets."),
                    citations=[], status="refused_budget", answer_grade_hint="refused",
                    first_token_ms=None, total_ms=0, retries=0, tokens_in=0, tokens_out=0,
                    retrieval_setting=self.retrieval_setting,
                )

        t_start = time.monotonic()

        # --- step 1: classify intent + query extraction (cheap heuristic instead of
        # a second LLM call for in-scope/out-of-scope, to save tokens/budget; a real
        # system would use a tiny model here) ---
        search_query = question

        # --- step 2+3: retrieve, with sufficiency loop ---
        k = 5
        retrieved = self.retriever.search(search_query, k=k)
        best_score = max((rc.score for rc in retrieved), default=0.0)
        loops = 0
        while best_score < SUFFICIENCY_SCORE_THRESHOLD and loops < MAX_RETRIEVE_LOOPS:
            search_query = _broaden_query(search_query)
            k += 3
            retrieved = self.retriever.search(search_query, k=k)
            best_score = max((rc.score for rc in retrieved), default=0.0)
            loops += 1

        context = _format_context(retrieved)
        insufficient = best_score < SUFFICIENCY_SCORE_THRESHOLD

        # --- step 4: draft ---
        system_prompt = (
            "You are an assistant that answers ONLY using the provided excerpts from three papers. "
            "Every factual sentence must end with a citation tag like [paper_id pN] copied exactly from "
            "the excerpt it came from. If the excerpts do not contain the answer, reply exactly: "
            "\"The papers do not say.\" Do not guess or use outside knowledge."
        )
        user_prompt = f"Excerpts:\n{context}\n\nQuestion: {question}\n\nAnswer with citations:"
        if insufficient:
            user_prompt = (
                f"Excerpts (may be insufficient):\n{context}\n\nQuestion: {question}\n\n"
                "If these excerpts do not answer the question, reply exactly: \"The papers do not say.\""
            )

        messages = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}]
        result = self.client.chat_stream(messages, max_tokens=self.max_tokens)
        stream_results.append(result)

        if result.status != "ok":
            total_ms = (time.monotonic() - t_start) * 1000
            return PipelineResult(
                request_id=request_id, answer="", citations=[], status=result.status,
                answer_grade_hint="refused", first_token_ms=result.first_token_ms, total_ms=total_ms,
                retries=retries, tokens_in=result.tokens_in, tokens_out=result.tokens_out,
                retrieval_setting=self.retrieval_setting, stream_results=stream_results,
            )

        answer_text = result.text
        citations = _extract_citations(answer_text)

        # --- step 5: citation-verify branch ---
        is_refusal = "the papers do not say" in answer_text.lower()
        if not is_refusal and not _citations_valid(citations, retrieved):
            retries += 1
            strict_prompt = (
                f"Excerpts:\n{context}\n\nQuestion: {question}\n\n"
                "Your previous answer had citations that did not match the excerpts. "
                "Re-answer, citing ONLY tags exactly as they appear above (e.g. [paper_id pN]). "
                "If you cannot support the answer with these excerpts, reply exactly: \"The papers do not say.\""
            )
            messages2 = [{"role": "system", "content": system_prompt}, {"role": "user", "content": strict_prompt}]
            result2 = self.client.chat_stream(messages2, max_tokens=self.max_tokens)
            stream_results.append(result2)
            if result2.status == "ok":
                answer_text2 = result2.text
                citations2 = _extract_citations(answer_text2)
                is_refusal2 = "the papers do not say" in answer_text2.lower()
                if is_refusal2 or _citations_valid(citations2, retrieved):
                    answer_text, citations, is_refusal = answer_text2, citations2, is_refusal2
                else:
                    answer_text = "The papers do not say (could not verify citations for this answer)."
                    citations = []
                    is_refusal = True

        total_ms = sum(sr.total_ms for sr in stream_results)
        first_token_ms = stream_results[0].first_token_ms
        tokens_in = sum(sr.tokens_in for sr in stream_results)
        tokens_out = sum(sr.tokens_out for sr in stream_results)

        return PipelineResult(
            request_id=request_id, answer=answer_text, citations=citations,
            status="ok", answer_grade_hint="refused" if is_refusal else "answered",
            first_token_ms=first_token_ms, total_ms=total_ms, retries=retries,
            tokens_in=tokens_in, tokens_out=tokens_out, retrieval_setting=self.retrieval_setting,
            stream_results=stream_results,
        )
